slowDuration = 3
dropTypes = {
{"bat",function(x,y,t)
gfx.push()
setColor(white)
gfx.circle("fill",x,y,0.4)
gfx.translate(x,y)
gfx.rotate(t%8/4*pi)
gfx.translate(0,0.35)
gfx.scale(2/3)
renderWeapon("bat")
gfx.pop()
end,function(player)
	if not player.weapon and player.weaponTimeout < curTime and player.weaponFired then
		player.weapon = "bat"
		player.weaponUses = 0
		return true
	end
end,1 --[[This value also exists in the gamemode changing]]};
{"bow",function(x,y,t)
gfx.push()
setColor(white)
gfx.circle("fill",x,y,0.4)
gfx.translate(x,y)
gfx.rotate(t%8/4*pi)
gfx.scale(2/3)
renderWeapon("bow")
gfx.pop()
end,function(player)
	if not player.weapon and player.weaponTimeout < curTime and player.weaponFired then
		player.weapon = "bow"
		player.weaponUses = 0
		return true
	end
end,1 --[[This value also exists in the gamemode changing]]};
{"health",function(x,y)
setColor(white)
gfx.circle("fill",x,y,0.3)
setColor(red)
rectangle("fill",x-0.2,y-0.05,0.4,0.1)
rectangle("fill",x-0.05,y-0.2,0.1,0.4)
end,function(player)
	if player.health >= 100 then return end
	player.health = player.health+30
	if player.health > 100 then player.health = 100 end
	return true
end,0.5};{"slow",function(x,y)
setColor(white)
gfx.circle("fill",x,y,0.4)
setColor(glass)
gfx.polygon("fill",x,y,x+0.04,y+0.0128,x+0.08,y+0.0512,x+0.16,y+0.2048,x-0.16,y+0.2048,x-0.08,y+0.0512,x-0.04,y+0.0128)
rectangle("fill",x-0.025,y-0.05,0.05,0.1)
gfx.polygon("fill",x,y,x+0.04,y-0.0128,x+0.08,y-0.0512,x+0.16,y-0.2048,x-0.16,y-0.2048,x-0.08,y-0.0512,x-0.04,y-0.0128)
setColor(black)
rectangle("fill",x-0.16,y-0.2298,0.32,0.05)
rectangle("fill",x-0.16,y+0.1798,0.32,0.05)
setColor(gold)
rectangle("fill",x-0.16,y-0.1798,0.05,0.3596)
rectangle("fill",x+0.11,y-0.1798,0.05,0.3596)
end,function(player)
	slowTimeout = curTime+slowDuration
	return true
end,0.4};{"fast",function(x,y)
setColor(black)
gfx.circle("fill",x,y,0.35)
setColor(240,240,0)
gfx.polygon("fill",x-0.12,y+0.3,x+0.1,y-0.05,x+0.025,y-0.05,x-0.025,y+0.05)
gfx.polygon("fill",x+0.12,y-0.3,x-0.1,y+0.05,x-0.025,y+0.05,x+0.025,y-0.05)
end,function(player)
	player.speedTimeout = curTime+7
	return true
end,1};
{"invincible",function(x,y,t,tr)
setColor(black)
gfx.circle("fill",x,y,0.35)
gfx.setLineWidth(0.05)
setColor(teal)
gfx.circle("line",x,y,0.2)
end,function(player)
	player.forceTimeout = curTime+5.5
	return true
end,1};
{"jetboots",function(x,y,t,tr)
setColor(white)
gfx.circle("fill",x,y,0.35)
setColor(brown)
rectangle("fill",x-0.12,y-0.2,0.24,0.3)
rectangle("fill",x+0.12,y-0.05,0.1,0.15)
setColor(black)
rectangle("fill",x-0.12,y+0.05,0.34,0.05)
end,function(player)
	if not player.jetbootsTotal then
		player.jetbootsTotal = 8 -- Max flight before boots disappear
		return true
	end
end,1};
{"armor",function(x,y,t,tr)
setColor(white)
gfx.circle("fill",x,y,0.35)
setColor(gray)
rectangle("fill",x-0.13,y-0.18,0.26,0.36)
rectangle("fill",x+0.13,y-0.18,0.08,0.12)
rectangle("fill",x-0.21,y-0.18,0.08,0.12)
end,function(player)
	if not player.armor then
		local set = love.math.randomNormal(20,60)
		player.armor = set < 30 and 30 or set
		return true
	end
end,1};
}
function weighDrops()
	totalDropWeight = 0
	for _,v in pairs(dropTypes) do
		totalDropWeight = totalDropWeight+v[4]
	end
end
weighDrops()