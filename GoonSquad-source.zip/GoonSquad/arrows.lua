function drawArrow(arrow,trans)
	gfx.push()
	gfx.translate(arrow.x,arrow.y)
	gfx.rotate(arrow.dir)
	setColor(133,102,93,trans)
	gfx.polygon("fill",0.69,-0.03,0.69,0.03,0.09,0.03,0.09,-0.03)
	setColor(255,255,255,trans)
	gfx.polygon("fill",0.05,-0.05,0.15,0,0,0,-0.1,-0.05)
	gfx.polygon("fill",0.15,0,0.05,0.05,-0.1,0.05,0,0)
	setColor(171,171,171,trans)
	gfx.polygon("fill",0.90,0,0.69,0.08,0.69,-0.08)
	gfx.pop()
end
function newArrow(x,y,dir,owner)
	table.insert(arrows,{x=x,y=y,dir=dir,dir2=dir,velocity=60,grav=0,owner=owner})
end
local arrowLifetime = 15 -- time alive after hitting wall
function drawArrows()
	for i = 1, #arrows do
		local arrow = arrows[i]
		if arrow.static then
			drawArrow(arrow,arrow.life/arrowLifetime*255)
		else
			if arrow.pre2 then
				drawArrow(arrow.pre2,128)
			end
			drawArrow(arrow)
		end
	end
end
function updateArrows(dt)
	local gravInc12 = 12*dt
	for i = #arrows, 1, -1 do -- arrow physics
		local arrow = arrows[i]
		if arrow.static then
			arrow.life = arrow.life-dt
			if arrow.life <= 0 then
				table.remove(arrows,i)
			end
		else
			arrow.pre2 = arrow.pre
			local pre = {x=arrow.x,y=arrow.y,dir=arrow.dir}
			arrow.pre = pre
			arrow.velocity = arrow.velocity*0.3^dt
			arrow.x = arrow.x+math.cos(arrow.dir2)*arrow.velocity*dt
			arrow.y = arrow.y+(math.sin(arrow.dir2)*arrow.velocity+(arrow.grav+gravInc12))*dt
			arrow.dir = math.atan2(math.sin(arrow.dir2)*arrow.velocity+(arrow.grav+gravInc12),math.cos(arrow.dir2)*arrow.velocity)
			arrow.grav = arrow.grav+gravInc12*2 -- gravity acceleration
			local ded = false
			if arrow.y > 50 then -- destroy
				table.remove(arrows,i)
				ded = true
			else -- check players
				local hits = hitPlayersLine(pre.x,pre.y,arrow.x,arrow.y,arrow.owner)
				if #hits > 0 then -- hit a person
					local playForce = false
					for _,v in pairs(hits) do
						if v.forceTimeout > curTime then
							playForce = true
						end
						damage(v,22*(arrow.owner.menuValues[2] == "Michael" and 1.2 or 1),nil,arrow.dir) -- damage mod with Michael
					end
					if playForce then
						sounds.forceHit:play()
					else
						sounds.arrowToPlayer:play()
					end
					sounds.blood:play()
					table.remove(arrows,i)
					ded = true
				end
			end
			if not ded then -- check world
				for i2 = 1, #world do
					local part = world[i2]
					local x0,y0 = part[1],part[2]
					local x1,y1 = x0+part[3],y0+part[4]
					local arrowX,arrowY = math.cos(arrow.dir)*0.8,math.sin(arrow.dir)*0.8
					local xend,yend = arrow.x+arrowX,arrow.y+arrowY
					local hitPoint = lineX(x0,y0,x0,y1,pre.x,pre.y,xend,yend) or lineX(x0,y0,x1,y0,pre.x,pre.y,xend,yend) or lineX(x1,y0,x1,y1,pre.x,pre.y,xend,yend) or lineX(x0,y1,x1,y1,pre.x,pre.y,xend,yend)
					if hitPoint then -- hit world
						sounds.arrowToWall:play()
						local depth = 1-math.random()*0.3
						arrow.x,arrow.y = hitPoint[1]-arrowX*depth,hitPoint[2]-arrowY*depth
						arrow.static = true
						arrow.life = arrowLifetime
						break
					end
				end
			end
		end
	end
end