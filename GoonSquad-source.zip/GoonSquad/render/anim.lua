function renderAnimFrame(x,y,dir,frame,color,character,extra)
	if not extra then extra = {}end
	local health,weapon,boots,armor,ghost = extra.health or 100,extra.weapon,extra.boots,extra.armor,extra.ghost
	local le,re = frame.le or 0,frame.re or 0
	if extra.armor then
		armor = 80+armor
		armor = {armor,armor,armor,color[4]}
	end
	gfx.push()
	if frame.rotate and health > 0 then
		gfx.translate(x,y-1+frame.oY)
		gfx.rotate(frame.rotate*dir)
		gfx.translate(0,1)
	else
		gfx.translate(x,y+frame.oY)
	end
	if health <= 0 then
		gfx.translate(0,-0.1)
		gfx.rotate(pi/2*dir)
	end
	-- begin drawing
	setColor(color)
	drawLeg(frame.rl,frame.rk,dir,boots and not ghost) -- right leg
	setColor(color)
	drawLeg(frame.ll,frame.lk,dir,boots and not ghost) -- left leg
	setColor(color)
	if dir == 1 then -- draw first arm
		drawArm(frame.la,le,frame.lex or 0,dir,color,armor)
	else
		drawArm(frame.ra,re,frame.rex or 0,dir,color,armor,weapon)
	end
	if armor then -- torso
		setColor(armor)
		rectangle("fill",-0.14,-1.6,0.28,0.75) -- torso
		setColor(color)
	else
		setColor(color)
		rectangle("fill",-0.1,-1.6,0.2,0.75) -- torso
	end
	drawHead(color,character,dir,not ghost)
	setColor(color)
	if dir == 1 then -- draw second arm
		drawArm(frame.ra,re,frame.rex or 0,dir,color,armor,weapon)
	else
		drawArm(frame.la,le,frame.lex or 0,dir,color,armor)
	end
	if weapon =="bow" and not ghost then
		gfx.push()
		gfx.translate(0,-1.6)
		gfx.rotate(frame.la*dir)
		gfx.translate(0,0.4)
		gfx.rotate(le*dir)
		gfx.translate(0,0.3+(frame.lex or 0))
		gfx.rotate(pi/2*dir)
		local function rotate(p,d)
			local mag = math.sqrt(p[1]*p[1]+p[2]*p[2])
			local de = math.atan2(p[2],p[1])+d
			p[1],p[2] = math.cos(de)*mag,math.sin(de)*mag
			return p
		end
		local function tran(p,o)
			p[1],p[2] = p[1]+o[1],p[2]+o[2]
			return p
		end
		local point = tran(rotate({0,-0.3-(frame.lex or 0)},-pi/2*dir),rotate({0,-0.4},-le*dir-pi/2*dir))
		point = tran(point,rotate({0,0.4},(-le-pi/2-frame.la+frame.ra)*dir))
		point = tran(point,rotate({0,0.3},(-le-pi/2-frame.la+frame.ra+re)*dir))
		renderWeapon("bow",color[4],dir,extra.arrow and {bx=point[1],by=point[2]})
		setColor(color)
		gfx.pop()
	end
	gfx.pop() -- go back to original
end
function drawArm(rot0,rot1,extend,dir,color,armor,weapon)
	gfx.push()
	gfx.translate(0,-1.6)
	gfx.rotate(rot0*dir)
	rectangle("fill",-0.09,0,0.18,0.4) -- arm
	if armor then
		setColor(armor)
		rectangle("fill",-0.12,0,0.24,0.35) -- arm
		setColor(color)
	end
	gfx.translate(0,0.4)
	gfx.rotate(rot1*dir)
	if weapon == "bat" then
		gfx.push()
		gfx.translate(-0.17*dir,0.2+extend)
		gfx.rotate(pi/2*dir)
		renderWeapon("bat",color[4],dir)
		setColor(color)
		gfx.pop()
	end
	rectangle("fill",-0.09,0,0.18,0.3+extend) -- below elbow
	gfx.pop()
end
function drawLeg(rot0,rot1,dir,boots)
	gfx.push()
	gfx.translate(0,-0.85)
	gfx.rotate(rot0*dir)
	rectangle("fill",-0.1,0,0.2,0.45) -- leg
	gfx.translate(0,0.45)
	gfx.rotate(rot1*dir)
	rectangle("fill",-0.1,0,0.2,0.4) -- knee
	if boots then
		setColor(brown)
		rectangle("fill",-0.12*dir,0.3-0.2,0.24*dir,0.3)
		rectangle("fill",0.12*dir,0.3-0.05,0.1*dir,0.15)
		setColor(black)
		rectangle("fill",-0.12*dir,0.3+0.05,0.34*dir,0.05)
	end
	gfx.pop()
end
function drawHead(color,character,dir,specials)
	rectangle("fill",-0.2,-2,0.4,0.4,0.1) -- head
	local alpha = color[4]
	setColor(0,0,0,alpha)
	rectangle("fill",0.06*dir,-1.73,0.14*dir,0.07) -- mouth
	if character == "Thaison" then
		rectangle("fill",0.06*dir,-1.9,0.1*dir,0.04) -- flat eye
	else
		rectangle("fill",0.06*dir,-1.9,0.08*dir,0.08) -- eye
	end
	if character == "Thaison" then
		setColor(0,0,0,alpha)
		rectangle("fill",-0.24*dir,-2.18,0.215*dir,0.45)
		gfx.polygon("fill",-0.025*dir,-2.18,0.25*dir,-2.23,0.167*dir,-1.97,-0.025*dir,-1.97)
	elseif character == "Devin" then
		setColor(171,135,88,alpha)
		gfx.polygon("fill",-0.23*dir,-1.95,-0.2*dir,-2,-0.08*dir,-2.03,0.18*dir,-2.01,0.21*dir,-1.91,0.01*dir,-1.91,-0.07*dir,-1.88,-0.12*dir,-1.9,-0.15*dir,-1.75,-0.21*dir,-1.74)
	elseif character == "Jake" then
		setColor(0,0,0,alpha)
		gfx.polygon("fill",-0.21*dir,-1.96,0.21*dir,-1.96,0.21*dir,-1.91,-0.21*dir,-1.91)
		gfx.polygon("fill",0.16*dir,-1.96,0.16*dir,-2.01,-0.16*dir,-2.01,-0.16*dir,-1.96)
		gfx.circle("fill",-0.16*dir,-1.96,0.05,20)
		gfx.circle("fill",0.16*dir,-1.96,0.05,20)
	elseif character == "Michael" and specials then
		setColor(196,196,98,alpha)
		gfx.polygon("fill",0.17*dir,-2.01,0.1*dir,-2.04,-0.06*dir,-2.07,-0.2*dir,-2.02,-0.21*dir,-1.93,0.2*dir,-1.97)
		gfx.polygon("fill",-0.07*dir,-1.95,-0.07*dir,-1.87,-0.2*dir,-1.84,-0.21*dir,-1.93)
		gfx.polygon("fill",-0.07*dir,-1.87,-0.07*dir,-1.84,-0.1*dir,-1.82,-0.19*dir,-1.85)
		gfx.polygon("fill",-0.09*dir,-1.97,-0.08*dir,-1.91,0.01*dir,-1.96)
		setColor(241,255,0,alpha)
		gfx.polygon("fill",-0.03*dir,-2.25,0.03*dir,-2.25,0.03*dir,-2.29,-0.03*dir,-2.29)
		setColor(84,84,84,alpha)
		gfx.polygon("fill",-0.03*dir,-2.21,0.03*dir,-2.21,0.03*dir,-2.25,-0.03*dir,-2.25)
		setColor(241,255,0,alpha)
		gfx.polygon("fill",-0.05*dir,-2.3,-0.03*dir,-2.26,0.03*dir,-2.26,0.05*dir,-2.3)
		gfx.circle("fill",0*dir,-2.37,0.09,20)
		setColor(84,84,84,alpha)
		gfx.circle("fill",0*dir,-2.21,0.03,20)
	elseif character == "Chase" and specials then
		setColor(255,255,255,alpha)
		gfx.polygon("fill",0.12*dir,-0.88,0.14*dir,-0.84,0.12*dir,-0.74,0.06*dir,-0.64,-0.08*dir,-0.7,-0.14*dir,-0.76,-0.14*dir,-0.9)
		gfx.polygon("fill",0*dir,-0.66,-0.12*dir,-0.6,-0.14*dir,-0.78)
		gfx.polygon("fill",-0.04*dir,-0.72,-0.02*dir,-0.66,0.02*dir,-0.68)
		gfx.polygon("fill",-0.01*dir,-0.67,0.01*dir,-0.67,-0.02*dir,-0.65,-0.02*dir,-0.66)
		gfx.polygon("fill",-0.03*dir,-0.68,-0.01*dir,-0.65,0.02*dir,-0.66)
		gfx.polygon("fill",-0.06*dir,-0.63,-0.04*dir,-0.62,-0.01*dir,-0.65)
		gfx.polygon("fill",-0.06*dir,-0.63,-0.03*dir,-0.67,-0.01*dir,-0.65)
		gfx.polygon("fill",-0.12*dir,-1.42,-0.16*dir,-1.28,-0.14*dir,-1.14,-0.14*dir,-0.9,-0.08*dir,-0.8,0.04*dir,-0.8,0.12*dir,-0.88,0.12*dir,-0.98,0.14*dir,-1.3,0.1*dir,-1.48,-0.14*dir,-1.6)
		setColor(161,28,14,alpha)
		gfx.polygon("fill",0.17*dir,-1.98,0.12*dir,-2,-0.12*dir,-2,-0.2*dir,-1.96,-0.2*dir,-1.88,0*dir,-1.92,0.16*dir,-1.96)
		gfx.polygon("fill",-0.12*dir,-1.9,-0.22*dir,-1.64,-0.28*dir,-1.54,-0.32*dir,-1.6,-0.28*dir,-1.64,-0.28*dir,-1.72,-0.26*dir,-1.86,-0.2*dir,-1.96)
		gfx.polygon("fill",-0.28*dir,-1.58,-0.18*dir,-1.58,-0.2*dir,-1.68)
		gfx.polygon("fill",-0.26*dir,-1.66,-0.22*dir,-1.6,-0.18*dir,-1.64,-0.2*dir,-1.74)
		gfx.polygon("fill",0*dir,-1.7,0.04*dir,-1.66,0.06*dir,-1.62,0.06*dir,-1.56,0.12*dir,-1.5,0.16*dir,-1.56,0.2*dir,-1.64,0.16*dir,-1.66,0.06*dir,-1.68,0.02*dir,-1.7)
		gfx.polygon("fill",0.06*dir,-1.64,-0.04*dir,-1.68,-0.08*dir,-1.8,-0.08*dir,-1.94,0*dir,-1.96,0.02*dir,-1.86,0.06*dir,-1.66)
		gfx.polygon("fill",-0.06*dir,-1.83,-0.06*dir,-1.93,-0.14*dir,-1.93,-0.16*dir,-1.81,-0.07*dir,-1.84)
		gfx.polygon("fill",-0.16*dir,-1.85,-0.18*dir,-1.77,-0.11*dir,-1.83)
		setColor(97,18,8,alpha)
		gfx.polygon("fill",-0.14*dir,-1.04,-0.04*dir,-1.02,0.12*dir,-1,0.12*dir,-1.08,0*dir,-1.08,-0.14*dir,-1.08)
		gfx.polygon("fill",0.12*dir,-1,0.14*dir,-1.02,0.14*dir,-1.06,0.12*dir,-1.1)
		gfx.polygon("fill",0.12*dir,-1.08,0.1*dir,-1.08,0.12*dir,-1.1)
		gfx.polygon("fill",-0.27*dir,-1.73,-0.25*dir,-1.71,-0.22*dir,-1.7,-0.2*dir,-1.69,-0.19*dir,-1.7,-0.2*dir,-1.71,-0.23*dir,-1.74,-0.28*dir,-1.75)
		gfx.polygon("fill",-0.25*dir,-1.75,-0.22*dir,-1.73,-0.27*dir,-1.72,-0.28*dir,-1.75,-0.26*dir,-1.75)
	elseif character:sub(1,7) == "Custom " and specials then
		local n = tonumber(character:sub(8,-1))
		customCharacters[n](dir,color)
	end
end
function renderWeapon(weapon,alpha,dir,extra)
	if not dir then dir = 1 end
	if weapon == "bat" then
		setColor(brown[1],brown[2],brown[3],alpha)
		rectangle("fill",-0.12,-0.08,0.24,0.08,0.02)
		gfx.polygon("fill",-0.06,-0.08,
		-0.1,-0.9,
		-0.06,-1.05,
		0.06,-1.05,
		0.1,-0.9,
		0.06,-0.08)
	elseif weapon == "bow" then
		setColor(207,207,207,alpha)
		gfx.polygon("fill",-0.04*dir,0.09,0.04*dir,0.09,0.04*dir,-0.09,-0.04*dir,-0.09)
		gfx.setLineWidth(0.02)
		if extra then
			gfx.line(-0.21*dir,-0.65,extra.bx,extra.by)
			gfx.line(-0.21*dir,0.65,extra.bx,extra.by)
		else
			gfx.line(-0.21*dir,-0.65,-0.21*dir,0.65)
		end
		setColor(130,104,60,alpha)
		gfx.polygon("fill",-0.04*dir,-0.23,0.04*dir,-0.23,0.04*dir,-0.09,-0.04*dir,-0.09)
		gfx.polygon("fill",0.04*dir,-0.23,0.02*dir,-0.32,-0.06*dir,-0.32,-0.04*dir,-0.23)
		gfx.polygon("fill",0.02*dir,-0.32,-0.02*dir,-0.41,-0.1*dir,-0.41,-0.06*dir,-0.32)
		gfx.polygon("fill",-0.02*dir,-0.41,-0.1*dir,-0.53,-0.16*dir,-0.51,-0.1*dir,-0.41)
		gfx.polygon("fill",-0.1*dir,-0.53,-0.17*dir,-0.62,-0.22*dir,-0.59,-0.16*dir,-0.51)
		gfx.polygon("fill",-0.17*dir,-0.62,-0.21*dir,-0.67,-0.25*dir,-0.63,-0.22*dir,-0.59)
		gfx.polygon("fill",-0.17*dir,-0.62,-0.21*dir,-0.67,-0.25*dir,-0.63,-0.22*dir,-0.59)
		gfx.push()
		gfx.scale(1,-1)
		gfx.polygon("fill",-0.04*dir,-0.23,0.04*dir,-0.23,0.04*dir,-0.09,-0.04*dir,-0.09)
		gfx.polygon("fill",0.04*dir,-0.23,0.02*dir,-0.32,-0.06*dir,-0.32,-0.04*dir,-0.23)
		gfx.polygon("fill",0.02*dir,-0.32,-0.02*dir,-0.41,-0.1*dir,-0.41,-0.06*dir,-0.32)
		gfx.polygon("fill",-0.02*dir,-0.41,-0.1*dir,-0.53,-0.16*dir,-0.51,-0.1*dir,-0.41)
		gfx.polygon("fill",-0.1*dir,-0.53,-0.17*dir,-0.62,-0.22*dir,-0.59,-0.16*dir,-0.51)
		gfx.polygon("fill",-0.17*dir,-0.62,-0.21*dir,-0.67,-0.25*dir,-0.63,-0.22*dir,-0.59)
		gfx.polygon("fill",-0.17*dir,-0.62,-0.21*dir,-0.67,-0.25*dir,-0.63,-0.22*dir,-0.59)
		gfx.pop()
		if extra then
			drawArrow({x=extra.bx,y=extra.by,dir=-0.1*dir+(dir == -1 and pi or 0)})
		end
	end
end
function getFrame(anim,alpha)
	local num = #anim
	local times = anim[1]
	local frameNum
	for i = #times, 1, -1 do
		if alpha >= times[i] then
			frameNum = i+1
			break
		end
	end
	local time1 = times[frameNum-1]
	return mixFrames(anim[frameNum],anim[frameNum+1],(alpha-time1)/(times[frameNum]-time1))
end
function getFrameMixMax(anim,alpha) -- use this for animations that do not use all the possible joints and such
	local num = #anim
	local times = anim[1]
	local frameNum
	for i = #times, 1, -1 do
		if alpha >= times[i] then
			frameNum = i+1
			break
		end
	end
	local time1 = times[frameNum-1]
	return mixMaxFrames(anim[frameNum],anim[frameNum+1],(alpha-time1)/(times[frameNum]-time1))
end
function mixMaxFrames(a,b,c)
	local d = 1-c
	local out = {}
	for i,v in pairs(a) do
		out[i] = v*d+b[i]*c
	end
	return out
end
function mixFrames(a,b,c)
	local d = 1-c
	local out = {ra=a.ra*d+b.ra*c,la=a.la*d+b.la*c,ll=a.ll*d+b.ll*c,rl=a.rl*d+b.rl*c,rk=a.rk*d+b.rk*c,lk=a.lk*d+b.lk*c,oY=a.oY*d+b.oY*c}
	return out
end
function overFrames(a,b,c)
	local d = 1-c
	local out = {}
	for i,v in pairs(a) do
		out[i] = v
	end
	for i,v in pairs(b) do
		if a[i] then
			out[i] = a[i]*d+v*c
		else
			out[i] = v*c
		end
	end
	return out
end