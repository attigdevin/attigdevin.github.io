function drawCharacterSelection(menuTime)
	local dt = menuTime-startTime
	if dt < 6 and not menuResources.skipTitleScreen then
		local a,alp
		if dt < 5 then
			a = dt < 1 and 0 or (dt-1)/4
			a = math.sin(a*pi12)*255
		else
			a = 255
			alp = (6-dt)
			alp = math.sin(alp*pi12)*255
		end
		setColor(a,a*0.3,0,alp)
		gfx.draw(menuResources.title,0,0,0,w/1920)
	else
		if not menuResources.skipTitleScreen then menuResources.skipTitleScreen = true end
		local dt = menuTime-menuResources.titleTime
		local sc = menuResources.renderScale
		local alpha = dt < 1 and dt or 1
		if alpha == 1 then
			alpha = nil
		else
			alpha = alpha*255
		end
		local ready = 0
		setColor(255,255,255,alpha)
		gfx.printf("Press start or connect a controller",0,h-48,w,"center")
		local j = 0
		for i,v in pairs(players) do
			local c = playerColors[i]
			c = {c[1],c[2],c[3],alpha}
			local name = v.menuValues[2]
			setColor(255-c[1]*0.2,255-c[2]*0.2,255-c[3]*0.2,alpha)
			local sc,y = sc
			if numPlayers > 4 then
				sc = sc*0.7
				y = (j <= 3 and h*0.11 or h*0.61)-48
			else
				y = h*0.5-sc*2
			end
			local j2 = j%4
			gfx.rectangle("fill",w/4*(j2+0.2),y,w*0.15,sc*2+96)
			if v.ready then
				setColor(readyColor[1],readyColor[2],readyColor[3],alpha)
				gfx.printf("Ready!",w/4*j2,y+sc*2,w/4,"center")
				ready = ready+1
			end
			setColor(c)
			gfx.printf(name,w/4*j2,y+sc*2+48,w/4,"center")
			local cx,cy = w/4*(j2+0.2)+24,y+sc*2+72
			gfx.polygon("fill",cx-20,cy,cx+10,cy+20*rt32,cx+10,cy-20*rt32)
			cx = w/4*(j2+0.8)-24
			gfx.polygon("fill",cx+20,cy,cx-10,cy+20*rt32,cx-10,cy-20*rt32)
			gfx.scale(sc)
			renderAnimFrame(w/4*(j2+0.5)/sc,(y+sc*2)/sc,1,getFrame(name ==  "Thaison" and animations.tardWalk or animations.walking,(menuTime+j/4)%1),c,v.menuValues[2])
			gfx.origin()
			setColor(c)
			gfx.printf("Player "..(j+1),w/4*(j2),y-48,w/4,"center")
			j = j+1
		end
		if ready == numPlayers and numPlayers > 0 then
			loadWorld(random(1,#worlds)) -- could move this to an update call instead of per tick
		end
	end
end