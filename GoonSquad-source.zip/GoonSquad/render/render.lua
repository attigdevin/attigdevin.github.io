require "render/anim"
require "render/select"
local taunts = {
["Flip"] = {
{0,0.4,0.45,0.6,0.75,0.75,0.85,1};{ll=0,lk=0,rl=0,rk=0,la=0,le=0,ra=0,re=0,rotate=0,oY=0};{ll=-1.4,lk=0.6,rl=-1.4,rk=0.6,la=0.9,le=-0.4,ra=0.9,re=-0.4,rotate=0.8,oY=0.2};
{ll=0,lk=0,rl=0,rk=0,la=-2.5,le=-1,ra=-2.5,re=-1,rotate=0,oY=0};{ll=0,lk=0,rl=0,rk=0,la=-2.5,le=-1,ra=-2.5,re=-1,rotate=-pi,oY=-2};
{ll=0,lk=0,rl=0,rk=0,la=-2.5,le=-1,ra=-2.5,re=-1,rotate=-pi2,oY=0},{ll=0,lk=0,rl=0,rk=0,la=-2.5,le=-1,ra=-2.5,re=-1,rotate=0,oY=0};
{ll=-0.5,lk=0.9,rl=-0.5,rk=0.9,la=0.5,le=-1.7,ra=0.5,re=-1.7,rotate=0,oY=0.2};{ll=-0.5,lk=0.9,rl=-0.5,rk=0.9,la=0.5,le=-1.7,ra=0.5,re=-1.7,rotate=0,oY=0.2};
}
}
local tauntLengths = {
["Flip"] = 2
}
local normFrame = {la=0,ra=0,ll=0,lk =0,rl=0,rk=0,oY=0}
local punchFrame1 = {ra=1.2,re=-2,la=-0.4,le=-2}
local punchFrame2 = {ra=-pi/2,re=0,la=1.4,le=-2,rex=0.5}
local batFrame1 = {ra=-1.7,re=-1.8,la=1.2,le=-1.2}
local batFrame2 = {ra=0.4,re=0.4,la=-0.7, le=-0.7}
local bowDraw = {le=0,re=-2.7,lex=-0.1}
local crouchFrame = {la=0.3,le=-1.8,re=-1.4,ra=-0.6,ll=-0.2,lk =1.5,rl=-1.1,rk=1.2,oY=0.2};
--[[walking = {
{"pre",mult=1.3};
{0,0.125,0.25,0.5,0.625,0.75,1};
normFrame;
{la=0.45,ra=-0.45,ll=0.2,lk=0.5,rl=-1,rk=1,oY=0.06};
{la=0.9,ra=-0.9,ll=0.2,lk=1,rl=-1,rk=1,oY=0.16};
normFrame;
{ra=0.45,la=-0.45,rl=0.2,rk=0.5,ll=-1,lk=1,oY=0.06};
{ra=0.9,la=-0.9,rl=0.2,rk=1,ll=-1,lk=1,oY=0.16};
normFrame;
};]]
animations = {
tardWalk = {
{"pre",mult=1.3};
{0,0.125,0.25,0.5,0.625,0.75,1};
{la=1,ra=0.6,ll=0,lk=0,rl=0,rk=0,oY=0};
{la=0.8,ra=0.8,ll=0.2,lk=0.5,rl=-1,rk=1,oY=0.06};
{la=0.6,ra=1,ll=0.2,lk=1,rl=-1,rk=1,oY=0.16};
{la=1,ra=0.6,ll=0,lk=0,rl=0,rk=0,oY=0};
{la=0.8,ra=0.8,rl=0.2,rk=0.5,ll=-1,lk=1,oY=0.06};
{la=0.6,ra=1,rl=0.2,rk=1,ll=-1,lk=1,oY=0.16};
{la=1,ra=0.6,ll=0,lk=0,rl=0,rk=0,oY=0};};
walking = {
{"pre",mult=1.3};
{0,0.125,0.25,0.5,0.625,0.75,1};
normFrame;
{la=0.45,ra=-0.45,ll=0.2,lk=0.5,rl=-1,rk=1,oY=0.06};
{la=0.9,ra=-0.9,ll=0.2,lk=1,rl=-1,rk=1,oY=0.16};
normFrame;
{ra=0.45,la=-0.45,rl=0.2,rk=0.5,ll=-1,lk=1,oY=0.06};
{ra=0.9,la=-0.9,rl=0.2,rk=1,ll=-1,lk=1,oY=0.16};
normFrame;
};
jumping = {{0,1};
normFrame;
{la=-1.5,ra=-2.5,ll=-1,lk=1.5,rl=0.4,rk=0.5,oY=0};};
air = {{0,0.5,1};
{la=-1.8,ra=1.8-pi*2,ll=-1.5,lk=0,rl=1.5,rk=0,oY=0};
{la=-2.5,ra=2.5-pi*2,ll=-0.5,lk=0,rl=0.5,rk=0,oY=0};
{la=-1.8,ra=1.8-pi*2,ll=-1.5,lk=0,rl=1.5,rk=0,oY=0};}
}
local fireWidth = 0.3
local fireWidth2 = fireWidth/2
function love.draw(dt)
	local menuTime = getTime()
	if winning then
		local det = menuTime-winning
		if det >= 1 and det < 2 then
			mode = 2
		end
	end
	if mode == 1 then
		if flash and flash > menuTime then
			setColor(255,0,0)
			rectangle("fill",0,0,w,h)
		end
		local transformData = {40*10^menuItems[3].value*w/1920}
		transformData[2],transformData[3] = -fx*transformData[1]+w/2,-fy*transformData[1]+h/2
		--[[ Background jizz
		setColor(white)
		local bgs = transformData[1]*0.4
		local wb = w/bgs
		local hb = h/bgs
		gfx.draw(bg,gfx.newQuad(fx-wb/2+50,fy-hb/2+30,wb,hb,100,60),0,0,0,bgs)
		--]]
		gfx.translate(transformData[2],transformData[3])
		gfx.scale(transformData[1])
		for i,v in pairs(drops) do -- draw drops
			local pos = world.drops[i]
			setColor(HSL(menuTime%10*25.5,200,150))
			gfx.circle("fill",pos[1],pos[2],0.45+0.05*(math.sin((menuTime%2)*pi)))
			local typ = dropTypes[v]
			typ[2](pos[1],pos[2],menuTime,transformData)
			local hits = hitPlayers(pos[1]-0.5,pos[2]-0.5,1,1) -- technically doesn't go here, should be in tick
			if #hits == 1 then
				if hits[1].health > 0 then
					if typ[3](hits[1]) then
						drops[i] = nil
					end
				end
			end
		end
		drawArrows() -- draw arrows
		drawPlayers(dt,menuTime) -- draw Players
		for i = 1, #world do -- draw world
			local part = world[i]
			setColor(part[5])
			rectangle("fill",part[1],part[2],part[3],part[4])
		end
		if pretty then
			blood:update(dt)
			jetParticles:update(dt)
			setColor(white)
			gfx.draw(blood)
			gfx.draw(jetParticles)
		end
	end
	gfx.origin()
	gfx.setFont(font36)
	setColor(white)
	gfx.print(love.timer.getFPS(),0,0)
	if message then
		local delta = message[2]-menuTime
		if delta > 0 then
			alpha = delta > 1 and 1 or delta
			setColor(255,255,255,255*alpha)
			gfx.printf(message[1],w/4,0,w/2,"center")
		end
	end
	if mode == 1 then
		if menu ~= 0 then -- draw menu
			setColor(255,255,255,230)
			local mx,my = w/4,h/4
			rectangle("fill",mx,my,w/2,h/2) -- draw menu background
			setColor(HSL(menuTime%10*25.5,200,150))
			cy = my+menuCursor*48
			gfx.circle("fill",mx+20,cy+25,12.5+2.5*(math.sin((menuTime%2)*pi)),12) -- cursor
			setColor(playerColors[menu])
			gfx.printf("Player number "..menu.." paused the game",mx,my+7,w/2,"center")
			for i = 1, #menuItems do
				setColor(menuColor)
				local item = menuItems[i]
				local itemY = my+i*48
				gfx.printf(item.name,mx+40,itemY,w/6)
				local value = item.value
				if item.nonStatic then
					value = (players[menu].menuValues)[i]
				end
				if item.type == "slider" then
					setColor(black)
					local width = w/2-80-w/6
					rectangle("fill",mx+40+w/6,itemY+14,width,20)
					local a = (value-item.min)/(item.max-item.min)
					setColor(skyblue)
					rectangle("fill",mx+40+w/6-5+a*width,itemY+8,10,32)
				elseif item.type == "rotate" then
					setColor(black)
					local width = w/2-80-w/6
					gfx.printf(value,mx+40+w/6,itemY,width,"center")
					setColor(HSL(menuTime%20*12.75,50,50))
					local r = 20
					local cx,cy = mx+40+w/6+r,itemY+24
					gfx.polygon("fill",cx-r,cy,cx+r*0.5,cy+r*rt32,cx+r*0.5,cy-r*rt32)
					cx = mx+40+w/6+width-r
					gfx.polygon("fill",cx+r,cy,cx-r*0.5,cy+r*rt32,cx-r*0.5,cy-r*rt32)
				end
			end
		end
		local ind = 0 -- draw health
		for i,v in pairs(players) do
			local x = ind*100
			local col = playerColors[i]
			setColor(col[1],col[2],col[3],200)
			rectangle("fill",x,h-100,100,100)
			setColor(255,255,255,128)
			local health = v.health/100
			gfx.setScissor(x,h-10-health*80,100,health*80)
			gfx.circle("fill",x+50,h-50,40)
			gfx.setScissor()
			ind = ind+1
		end
		if slowTimeout > curTime then
			gfx.push()
			gfx.scale(w)
			gfx.translate(0.5,0.05)
			setColor(white)
			gfx.circle("fill",0,0,0.015,20)
			gfx.setLineWidth(0.0015)
			setColor(HSL(menuTime%4*63.75,200,150))
			local ang = (1-(slowTimeout-curTime)/slowDuration)*pi2-pi12
			gfx.arc("line","open",0,0,0.015,-pi12,ang,20)
			setColor(black)
			gfx.circle("fill",0,0,0.002)
			gfx.line(0,0,math.cos(ang)*0.013,math.sin(ang)*0.013)
			for i = 1, 12 do
				gfx.setLineWidth(i%3 == 1 and 0.0013 or 0.0007)
				gfx.line(0,-0.01,0,-0.013)
				gfx.rotate(pi12/3)
			end
			gfx.pop()
		end
	elseif mode == 2 then -- title screen and character selection
		drawCharacterSelection(menuTime)
	end
	if winning then
		gfx.setFont(font108)
		local det = menuTime-winning
		if det < 1 then
			setColor(0,0,0,(menuTime-winning)*255)
			rectangle("fill",0,0,w,h)
		elseif det < 2 then
			if rungame then
				for _,v in pairs(players) do
					deded(v)
				end
				rungame = false
			end
			setColor(0,0,0)
			rectangle("fill",0,0,w,h)
			local a = (menuTime-winning-1)
			local col = playerColors[winner]
			setColor(col[1]*a,col[2]*a,col[3]*a)
			gfx.printf("Player "..winner.." wins!",0,h/2-54,w,"center")
		else
			local a = (1-menuTime+winning+2)*255
			setColor(0,0,0,a)
			rectangle("fill",0,0,w,h)
			local col = playerColors[winner]
			setColor(col[1],col[2],col[3],a)
			gfx.printf("Player "..winner.." wins!",0,h/2-54,w,"center")
			if det > 3 then
				winning,winner = nil
			end
		end
	end
	if numPlayers == 0 and mode == 1 then
		setColor(128,128,128)
		gfx.printf("No controllers detected, start with keyboard by pressing the configured start key",0,h/4,w,"center")
	end
end
function drawPlayers(dt,menuTime)
	for i,player in pairs(players) do -- draw players
		local char = player.menuValues[2]
		local isDevin = char == "Devin"
		local x,y = player[1],player[2]
		local frame = normFrame
		local dir = player.dir
		if pretty then -- render ghost frames
			local c = playerColors[i]
			local c1,c2,c3 = c[1],c[2],c[3]
			for i = #player.ghostFrames, 1, -1 do
				local v = player.ghostFrames[i]
				if curTime > v[5]+0.5 then
					table.remove(player.ghostFrames,i)
				else
					renderAnimFrame(v[1],v[2],v[3],v[4],{c1,c2,c3,255*(0.5-curTime+v[5])},char,{ghost=true,weapon=v[7],health=v[6]})
				end
			end
		end
		local frameExtras = {health=player.health,weapon=not player.breakWeapon and player.weapon,boots=player.jetbootsTotal,armor=player.armor}
		if player.health > 0 then
			--get main frames
			if player.crouch then
				frame = crouchFrame
			else
				if player[6] then
					frame = getAirFrame(curTime,player,nil,char)
				else
					frame = getFrame(char ==  "Thaison" and animations.tardWalk or animations.walking,player.walk)
					local dt = curTime-player.landTimeout
					if dt < 0.2 then
						frame = mixFrames(getAirFrame(curTime,player),frame,dt*5,char)
					end
				end
			end
			-- get weapon frames
			local bat = player.weapon == "bat"
			if player.weapon == "bow" then
				local bowSpeedMod = char == "Michael" and 0.6 or 1
				if player.weaponFired then
					if player.weaponFire <= curTime and curTime-player.weaponFire < 0.35*bowSpeedMod then -- just released an arrow
						local dt = (curTime-player.weaponFire)/bowSpeedMod
						if dt < 0.1 then
							frame = overFrames(frame,bowDraw,1)
						elseif dt < 0.35 then
							frame = overFrames(frame,bowDraw,1.4-dt*4)
						end
					end
				else
					local dt = (curTime-player.weaponCharging)/bowSpeedMod
					if dt > 0.25 then dt = 0.25 end
					stick = player[3]
					local xa,ya = stick:getAxis(1),stick:getAxis(2)
					local nxa = normal(xa)
					if player[4] == 0 then
						if nxa > 0 then
							player.dir = 1
						elseif nxa < 0 then
							player.dir = -1
						end
					end
					local of = (nxa == 0 and normal(ya) == 0 and 0) or math.atan2(ya,xa*player.dir)
					bowDraw.ra = pi12+of
					bowDraw.la = -math.pi/2+of
					frameExtras.arrow = true
					frame = overFrames(frame,bowDraw,dt*4)
				end
			elseif (bat or not player.weapon) and (player.broke ~= "bow")then -- bat and punching
				local attackFrame1 = bat and batFrame1 or punchFrame1
				local attackFrame2 = bat and batFrame2 or punchFrame2
				local punchSpeedMod = char == "Thaison" and 0.6 or 1 -- make Thaison go fast
				if player.weaponFire <= curTime and curTime-player.weaponFire < 0.55 then
					local dt = (curTime-player.weaponFire)/punchSpeedMod
					if dt < 0.15 then -- just released a punch
						if debuging then
							setColor(skyblue)
							rectangle("fill",player[1]+(dir == 1 and 0.4 or (bat and -1.4 or -1.2)),player[2]-1.69+(bat and 0.4 or 0)+(player.crouch and 0.2 or 0),0.8+(bat and 0.2 or 0),0.18)
						end
						frame = overFrames(overFrames(frame,attackFrame1,1),attackFrame2,dt*(1/0.15))
					elseif dt < 0.55 then -- recall punch
						frame = overFrames(frame,overFrames(overFrames(frame,attackFrame1,1),attackFrame2,1),1-(dt-0.15)/0.4)
					end
				elseif not player.weaponFired then -- charging, not released
					local dt = (curTime-player.weaponCharging)/punchSpeedMod
					if dt > 0.25 then dt = 0.25 end
					frame = overFrames(frame,attackFrame1,dt*4)
				end
			end
		end
		if isDevin and not player.crouch and player[6] then
			player.rotate = player.rotate+player[4]*dt
			frame.rotate = player.rotate*dir
		end
		if player.taunt then
			local dt = curTime-player.tauntStart
			local l = tauntLengths[player.taunt]
			local a = dt/l
			if a > 1 then
				player.taunt,player.tauntStart = nil
			else
				frame = overFrames(frame,getFrameMixMax(taunts[player.taunt],a),(dt < 0.2 and dt*5 or l-dt < 0.2 and (l-dt)*5 or 1))
			end
		end
		renderAnimFrame(x,y,dir,frame,playerColors[i],char,frameExtras)
		if player.forceTimeout > curTime then -- draw forcefield
			setColor(HSL(curTime/2%1*255,255,128))
			gfx.setLineWidth(0.08)
			gfx.ellipse("line",player[1],player[2]-1,0.8,1.5,20)
		end
		if pretty and curTime%0.1 < dt and player.speedTimeout > curTime then
			player.ghostFrames[#player.ghostFrames+1] = {x,y,dir,frame,curTime,player.health,player.weapon}
		end
		if debuging then
			setColor(skyblue)
			gfx.setLineWidth(0.05)
			rectangle("line",x-0.5,y-2,1,2)
		end
	end
end
function getAirFrame(curTime,player,nojump,name)
	local dt = nojump and 1 or curTime-player.jumpTimeout
	if dt < 0.3 and not nojump then
		frame = getFrame(animations.jumping,dt/0.3)
		if dt < 0.1 then
			local dt2 = curTime-player.landTimeout
			return mixFrames(dt2 < 0.1 and getAirFrame(curTime,player,true) or getFrame(name == "Thaison" and animations.tardWalk or animations.walking,player.walk),frame,dt*10)
		end
		return frame
	else
		if dt < 0.5 then
			return mixFrames(getFrame(animations.jumping,0.99),getFrame(animations.air,curTime*2%1),(dt-0.3)/0.2)
		else
			return getFrame(animations.air,curTime*2%1)
		end
	end
end
for _,v in pairs(animations) do -- preprocess animations
	if v[1][1] == "pre" then
		local pre = v[1]
		table.remove(v,1)
		if pre.mult then
			for i = 2, #v do
				local frame = v[i]
				for ind,j in pairs(frame) do
					frame[ind] = j*pre.mult
				end
			end
		end
	end
end