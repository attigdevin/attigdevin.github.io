local keyJoystick = {__index = function(t,key)
	if key == "getName" then
		return function(tab)
			return tab.name
		end
	elseif key == "isVibrationSupported" then
		return function()
			return false
		end
	elseif key == "getAxis" then
		return function(t,num)
			if num == 1 then
				local l,r = love.keyboard.isDown(t.left),love.keyboard.isDown(t.right)
				if l and not r then
					return -1
				elseif r and not l then
					return 1
				else
					return 0
				end
			elseif num == 2 then
				local u,d = love.keyboard.isDown(t.up),love.keyboard.isDown(t.down)
				if u and not d then
					return -1
				elseif d and not u then
					return 1
				else
					return 0
				end
			end
			error("No axis numbered "..num)
		end
	elseif key == "isDown" then
		return function(t,num)
			if t.buttons["b"..num] then
				return love.keyboard.isDown(t.buttons["b"..num])
			end
			error("No button numbered "..num)
		end
	end
end}
local keyboardWarrior1 = {type="keyboard",name="Keyboard Warrior #1",up="w",down="s",left="a",right="d",buttons={b2="q",b3="space",b4="space",b8="e",b1="lshift",b9="x"}}
setmetatable(keyboardWarrior1,keyJoystick)
local keyboardWarrior2 = {type="keyboard",name="Keyboard Warrior #2",up="kp8",down="kp5",left="kp4",right="kp6",buttons={b2="kp7",b3="kpenter",b4="kpenter",b8="kp9",b1="kp+"}}
setmetatable(keyboardWarrior2,keyJoystick)
local keyboardWarrior3 = {type="keyboard",name="Keyboard Warrior #3",up="i",down="k",left="j",right="l",buttons={b2="return",b3="return",b4="return",b8="o",b1="rshift"}}
setmetatable(keyboardWarrior3,keyJoystick)
local keyboardWarrior4 = {type="keyboard",name="Keyboard Warrior #4",up="up",down="down",left="left",right="right",buttons={b2=",",b3=",",b4=",",b8=".",b1="rctrl"}}
setmetatable(keyboardWarrior4,keyJoystick)
local wiimotes = {}
local wiimote = {
__index={isVibrationSupported = function(self)return false end,getName = function(self)return "Wiimote"end,isDown=
function(self,num)
	if num == 3 or num == 4 then
		return self.oldStick:isDown(2)
	elseif num == 1 then
		return self.oldStick:isDown(1)
	elseif num == 8 then
		return self.oldStick:isDown(3)
	end
end,getAxis=function(self,num)
	return self.oldStick:getAxis(num)
end
}}
function getWiiMote(stick)
	for i = 1, #wiimotes do
		local v = wiimotes[i]
		if v.oldStick == stick then
			return v
		end
	end
	local new = {oldStick=stick}
	setmetatable(new,wiimote)
	table.insert(wiimotes,new)
	return new
end
function love.joystickadded(stick)
	if stick:getName() =="Nintendo Wiimote" then
		joystickadded(getWiiMote(stick))
	else
		joystickadded(stick)
	end
end
function joystickadded(stick)
	for _,v in pairs(players) do
		if v[3] == stick then
			return
		end
	end
	message = {stick:getName().." just connected ".."Vibrates: "..tostring(stick:isVibrationSupported()),getTime()+5}
	loadPlayer(stick)
end
function love.joystickpressed(stick,button)
	if button == 3 then
		button = 1
	end
	if stick:getName() =="Nintendo Wiimote" then
		if button == 3 then
			button = 8
		end
		joystickpressed(getWiiMote(stick),button)
	else
		joystickpressed(stick,button)
	end
end
function joystickpressed(stick,button)
	if not menuResources.skipTitleScreen then
		menuResources.titleTime,menuResources.skipTitleScreen = getTime(),true
	end
	local num = 0
	local player
	for i,v in pairs(players) do
		if v[3] == stick then
			num = i
			player = v
			break
		end
	end
	if not player then
		if button == 8 then
			joystickadded(stick)
		end
		return
	end
	if rungame and player.health > 0 then -- alive and playing
		if button == 1 then
			if player.weapon == "bow" or player.weapon == "bat" or not player.wepaon then
				if player.weaponTimeout < curTime and player.weaponFired then
					player.broke = nil
					player.weaponFire = 0
					player.weaponCharging = curTime -- start charging
					player.weaponFired = false
				end
			end
		elseif button == 2 then
			-- do special
		elseif button == 9 then
			if not player[6] and not player.taunt then
				player[4] = 0
				player.taunt = "Flip"
				player.tauntStart = curTime
			end
		end
	end
	if mode == 2 then
		if button == 1 then
			player.ready = not player.ready
		end
	end
	if num == menu then -- if the press is the menu user's controller
		if button == 1 then
			local men = menuItems[menuCursor]
			if men.type == "button" then
				men.press(num)
			end
		end
	end
	if button == 8 then -- record down time
		if mode == 2 then
			love.joystickremoved(stick)
			return true
		else
			player.save.startDown = getTime()
		end
	end
end
function disconnect(stick)
	for i,player in pairs(players) do
		if player[3] == stick then
			players[i] = nil
			numPlayers = numPlayers-1
			if menu == i then
				menuOff()
			end
		end
	end
end
function love.joystickremoved(stick)
	message = {stick:getName().." is no longer connected",getTime()+5}
	disconnect(stick:getName() == "Nintendo Wiimote" and getWiiMote(stick) or stick)
end
function love.joystickreleased(stick,button)
	if button == 3 then
		button = 1
	end
	if stick:getName() =="Nintendo Wiimote" then
		if button == 3 then
			button = 8
		end
		joystickreleased(getWiiMote(stick),button)
	else
		joystickreleased(stick,button)
	end
end
function joystickreleased(stick,button)
	local num = 0
	local player
	for i,v in pairs(players) do
		if v[3] == stick then
			num = i
			player = v
			break
		end
	end
	if not player then return end
	if button == 1 and mode == 1 then
		local punchSpeedMod = (player.menuValues[2] == "Thaison" and 0.6) or 1
		local bowSpeedMod = player.menuValues[2] == "Michael" and 0.8 or 1
		if player.weapon == "bow" then
			if not player.weaponFired then
				player.punchHit,player.hitSound = {}
				player.weaponFire = math.max(curTime,player.weaponCharging+0.25*bowSpeedMod) -- charge time
			end
		elseif player.weapon == "bat" or not player.wepaon then
			if not player.weaponFired then
				player.punchHit,player.hitSound = {}
				player.weaponFire = math.max(curTime,player.weaponCharging+0.25*punchSpeedMod) -- charge time
			end
		end
	end
	if button == 8 and player.save.startDown then
		if getTime()-player.save.startDown > 1 then
			love.joystickremoved(stick)
		elseif mode == 1 then
			if num == menu then
				menuOff()
			elseif menu == 0 and not winning then
				menuCursor = 1
				menu = num
				rungame = false
			end
		end
	end
end
function getJoysticks()
	local out = {}
	for _,v in pairs(joy.getJoysticks()) do
		if v:getName() == "Nintendo Wiimote" then
			table.insert(out,getWiiMote(v))
		else
			table.insert(out,v)
		end
	end
	return out
end
function loadPlayers()
	local sticks = getJoysticks()
	for i = 1, #sticks do
		loadPlayer(sticks[i])
	end
end
function loadPlayer(stick,i,settings,save,spawns)
	if i then
		if not players[i] then
			initPlayer(stick,i,settings,save,spawns)
			return
		end
	end
	for i = 1, 20 do
		if not players[i] then
			initPlayer(stick,i,settings,save,spawns)
			return
		end
	end
end
function love.keyreleased(key)
	key = love.keyboard.getScancodeFromKey(key) -- convert to hardware located key
	for i,v in pairs(players) do
		local stick = v[3]
		if stick.type == "keyboard" then
			for i,v in pairs(stick.buttons) do
				if v == key then
					joystickreleased(stick,tonumber(i:sub(2,-1)))
				end
			end
		end
	end
end
function love.keypressed(key)
	key = love.keyboard.getScancodeFromKey(key) -- convert to hardware located key
	if not menuResources.skipTitleScreen then
		menuResources.titleTime,menuResources.skipTitleScreen = getTime(),true
	end
	if key == "escape" then
		love.event.quit()
	elseif key == "1" then
		vsync = not vsync
		love.window.setMode(w,h,{vsync=vsync,fullscreen=true})
	elseif key == "2" then
		debuging = not debuging
	elseif key == "3" then
		for i = 1, #dropTypes do
			if world.drops[i] then
				drops[i] = i
			end
		end
	elseif key == "4" then
		print(love.timer.getFPS())
	elseif key == "5" then
		wtf = not wtf
	elseif key == "6" then
		pretty = not pretty
	elseif key == "7" then
		dope = not dope
		gfx.setShader(dope and rainbowShader or nil)
	elseif key == "9" then
		gfx.newScreenshot():encode("png",os.time()..".png")
		love.system.openURL("file://"..love.filesystem.getSaveDirectory())
	end
	for i,v in pairs(players) do
		local stick = v[3]
		if stick.type == "keyboard" then
			for i,v in pairs(stick.buttons) do
				if v == key then
					if joystickpressed(stick,tonumber(i:sub(2,-1))) then return end -- if the controller is destroyed, don't keep checkin jizz
				end
			end
		end
	end
	if key == "e" then
		joystickadded(keyboardWarrior1)
	elseif key == "kp9" then
		joystickadded(keyboardWarrior2)
	elseif key == "o" then
		joystickadded(keyboardWarrior3)
	elseif key == "." or key == "/" or key == "?" then
		joystickadded(keyboardWarrior4)
	end
end