-- Converts HSL to RGB. (input and output range: 0 - 255)
function loadWorld(index)
	world = worlds[index]
	reset()
end
function HSL(h, s, l, a)
	if s<=0 then return l,l,l,a end
	h, s, l = h/256*6, s/255, l/255
	local c = (1-abs(2*l-1))*s
	local x = (1-abs(h%2-1))*c
	local m,r,g,b = (l-.5*c), 0,0,0
	if h < 1     then r,g,b = c,x,0
	elseif h < 2 then r,g,b = x,c,0
	elseif h < 3 then r,g,b = 0,c,x
	elseif h < 4 then r,g,b = 0,x,c
	elseif h < 5 then r,g,b = x,0,c
	else              r,g,b = c,0,x
	end return (r+m)*255,(g+m)*255,(b+m)*255,a
end
function startGame()
	mode,rungame = 1,true
	for i,v in pairs(players) do
		v.ready = nil
	end
end
function newSong()
	local music = sounds.music
	for i = 1, #music do
		local v = music[i]
		v[2]:stop()
	end
	if #music.toPlay == 0 then
		for i = 1, #music do
			table.insert(music.toPlay,i)
		end
	end
	local i = random(1,#music.toPlay)
	currentMusic = music[music.toPlay[i]]
	table.remove(music.toPlay,i)
	if not maxMusicVolume then
		currentMusic[2]:setVolume(0)
	else
		currentMusic[2]:setVolume(menuItems[4].value*currentMusic[3])
	end
	currentMusic[2]:play()
end
local stickEnd = 0.7
local stickStart = 0.1
function normal(input) -- normalize stick input
	local sign,ab = input < 0 and -1 or 1,abs(input)
	return ab < stickStart and 0 or ab > stickEnd and sign or (ab-stickStart)/(stickEnd-stickStart)*sign
end
function menuOff()
	for _,v in pairs(menuItems) do
		if v.menuClose then
			v.menuClose(v.value)
		end
	end
	menu = 0
	rungame = true
end
function reset(i,spawns)
	if i then
		local stick = players[i][3]
		local settings = players[i].menuValues
		local save = players[i].save
		if players[i].jetbootSound then
			players[i].jetbootSound:stop()
		end
		players[i] = nil
		numPlayers = numPlayers-1
		loadPlayer(stick,i,settings,save,spawns)
	else
		local spawns = {}
		for i = 1, #world.spawns do
			spawns[i] = world.spawns[i]
		end
		for i,v in pairs(players) do
			reset(i,spawns)
		end
		drops,slowTimeout,arrows = {},0,{}
		blood:reset()
		jetParticles:reset()
		startGame()
	end
end
local soundMeta = {__index={play=function(self,volume)
	if self.subsounds then
		self = self.subsounds[random(1,#self.subsounds)]
	end
	local volume = volume or 1
	local sounds = self.sounds
	for i = 1, #sounds do
		local v = sounds[i]
		if not v:isPlaying() and not v:isPaused() then
			v:setVolume(volume*self.volume)
			v:play()
			return v
		end
	end
	print("New sound")
	local new = sounds[1]:clone()
	table.insert(sounds,new)
	new:setVolume(volume*self.volume)
	new:setPitch(self.pitch*soundSpeed)
	new:play()
	return new
end}}
function lineX(x00,y00,x010,y010,x10,y10,x110,y110)
	local x01,y01,x11,y11 = x010-x00,y010-y00,x110-x10,y110-y10
	local d = x11*y01-x01*y11
	if d == 0 then
		return
	end
	local s = ((x00 - x10)*y01 - (y00 - y10)*x01)/d
	local t = -(-(x00 - x10)*y11 + (y00 - y10)*x11)/d
	if s >= 0 and s <= 1 and t >= 0 and t <= 1 then
		return {x00+x01*t,y00+y01*t}
	end
end
function newSound(source,pitch,volume)
	if source:find("#") then
		local sound = {subsounds={}}
		i = 1
		while true do
			local s = source:gsub("#",i)
			if love.filesystem.isFile(s) then
				sound.subsounds[i] = newSound(s,pitch,volume)
			else
				break
			end
			i = i+1
		end
		setmetatable(sound,soundMeta)
		return sound
	else
		local sound = {pitch=pitch,volume=volume,sounds={love.audio.newSource(source,"static")}}
		sound.sounds[1]:setPitch(pitch)
		sound.sounds[1]:setVolume(volume)
		setmetatable(sound,soundMeta)
		return sound
	end
end
function initPlayer(stick,i,settings,save,spawnSelect)
	spawnSelect = spawnSelect and #spawnSelect > 0 and spawnSelect
	local spawn = {0,-0.5}
	if world then
		local spawns = spawnSelect or world.spawns
		local spawnN = random(1,#spawns)
		spawn = spawns[spawnN]
		if spawnSelect then
			table.remove(spawnSelect,spawnN)
		end
	end
	players[i] = {spawn[1],spawn[2]+0.5,stick,0,0,false,rotate=0,jumpTimeout=0,walk=0,save=save or {},landTimeout=0,weaponTimeout=0,weaponFired=true,weaponFire=0,weaponCharging=0,health=100,dir=1,speedTimeout=0,forceTimeout=0,ghostFrames={},punchHit={},menuValues=settings or {nil,"Normal"}}
	if gamemode == "Bows" then
		players[i].weapon,players[i].weaponUses = "bow",0
	end
	numPlayers = numPlayers+1
end
function deded(player)
	if player.jetbootSound then
		player.jetbootSound:stop()
	end
end
function damage(player,damage,sdir,bloodAngle) -- getting hit, damage, +-1 blood direction if wanted, radian blood direction
	local ded
	if player.forceTimeout < curTime and player.health > 0 then
		if player.menuValues[2] == "Thaison" then
			damage = damage*1.25
		end
		if player.armor then
			if player.armor < damage then
				player.health = player.health+player.armor*0.3-damage
			else
				player.health = player.health-damage*0.7
			end
			player.armor = player.armor-damage
			if player.armor <= 0 then
				player.armor = nil
				sounds.breakArmor:play()--armor break sound
			end
		else
			player.health = player.health-damage
		end
		if player.health <= 0 then
			player.health = 0
			ded = true
			deded(player)
			checkWin()
		end
	end
	if pretty then
		blood:setSpin(-0.5*damage,0.5*damage)
		blood:setPosition(player[1],player[2]-1)
		if ded then
			blood:setSpeed(0,10+damage*2)
			blood:setSpread(pi2)
			blood:emit(200)
			blood:setSpread(1)
		else
			blood:setSpeed(0,5+damage)
			if sdir or bloodAngle then
				blood:setDirection(bloodAngle or (sdir == 1 and 0 or pi))
				blood:emit(autoRound(damage))
			else
				blood:setSpread(pi2)
				blood:emit(autoRound(damage))
				blood:setSpread(1)
			end
		end
	end
end
function autoRound(float) -- turn a float into an integer with random chance of rounding up
	return math.floor(float)+(random() < float%1 and 1 or 0)
end
function getGround(x,y,fat)
	local top,thick,effect
	for i = 1, #world do
		local part = world[i]
		if part[2]+part[4] > y and part[1] < x+fat and part[1]+part[3] > x then
			if not top or top > part[2] then
				top,thick,effect = part[2],part[4],part[6]
			end
		end
	end
	return top,thick,effect
end
function getXCollisions(x,y,dir)
	local worst
	for i = 1, #world do
		local part = world[i]
		if (x-0.5 < part[1]+part[3] and part[1] < x+0.5 and y-2 < part[2]+part[4] and part[2] < y) then
			if not worst or (dir == 1 and part[1] < worst or part[1]+part[3] > worst) then
				worst = dir == 1 and part[1] or part[1]+part[3]
			end
		end
	end
	return worst
end
function getUpCollisions(x,y)
	local worst
	for i = 1, #world do
		local part = world[i]
		if (x-0.5 < part[1]+part[3] and part[1] < x+0.5 and y-2 < part[2]+part[4] and part[2] < y) then
			if not worst or worst > part[2] then
				worst = part[2]+part[4]
			end
		end
	end
	return worst
end
function checkWin()
	if numPlayers <= 1 or winning then
		return
	end
	local alive,win = 0
	local num
	for _,v in pairs(players) do
		if v.health > 0 then
			alive = alive+1
			win = _
		end
	end
	if alive == 1 then
		winning,winner = getTime(),win
	end
end
function hitPlayersLine(x0,y0,x1,y1,exclude,deads) -- line seg, dealer, hit deads (Bool)
	local hit = {}
	for i,v in pairs(players) do
		if (deads or v.health > 0) and v ~= exclude and (lineX(x0,y0,x1,y1,v[1]-0.5,v[2]-2,v[1]-0.5,v[2]) or lineX(x0,y0,x1,y1,v[1]+0.5,v[2]-2,v[1]+0.5,v[2]) or lineX(x0,y0,x1,y1,v[1]+0.5,v[2]-2,v[1]-0.5,v[2]-2) or lineX(x0,y0,x1,y1,v[1]+0.5,v[2],v[1]-0.5,v[2])) then
			table.insert(hit,v)
		end
	end
	return hit
end
function hitPlayers(x,y,w,h,exclude,deads) -- rectangle, dealer, hit deads (Bool)
	local hit = {}
	local xw = x+w
	local yh = y+h
	for i,v in pairs(players) do
		if (deads or v.health > 0) and v ~= exclude and v[1]-0.5 < xw and x < v[1]+0.5 and v[2]-2 < yh and y < v[2] then
			table.insert(hit,v)
		end
	end
	return hit
end