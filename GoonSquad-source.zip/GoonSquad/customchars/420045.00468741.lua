local dir = ({...})[1]
setColor(255,127,2)
gfx.polygon("fill",0.02*dir,-1.94,-0.1*dir,-1.9,-0.14*dir,-1.68,-0.22*dir,-1.66,-0.24*dir,-1.86,-0.22*dir,-1.98,-0.16*dir,-2.04,0.14*dir,-2.04,0.22*dir,-2,0.18*dir,-1.94)
setColor(12,130,255)
gfx.polygon("fill",-0.1*dir,-1.42,0*dir,-1.42,0*dir,-1.52,-0.1*dir,-1.6)
gfx.polygon("fill",0*dir,-1.42,0.1*dir,-1.4,0.12*dir,-1.6,0*dir,-1.52)
gfx.polygon("fill",-0.12*dir,-0.9,0.1*dir,-0.92,0.1*dir,-1.44,-0.1*dir,-1.42)
