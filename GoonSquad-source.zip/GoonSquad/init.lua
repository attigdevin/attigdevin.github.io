--Boot properties
vsync = true
local worldFiles = {}
local worldFilesDir = love.filesystem.getDirectoryItems("maps/active")
for i = 1, #worldFilesDir do
	if worldFilesDir[i] ~= "desktop.ini" then
		table.insert(worldFiles,"active/"..worldFilesDir[i])
	end
end
--Constants
pi = math.pi
pi2 = 2*pi
pi12 = pi/2
rt32 = 3^0.5/2
abs = math.abs
require "color"
--Initials
mode = 2 -- Selection = 0 Game = 1 Title = 2 Other/None = -1
drops,arrows,worlds = {},{},{}
slowTimeout,epicSlow,soundSpeed = 0,0,1
pretty = true
blood = {}
players = {}
gamemode = "Normal"
numPlayers = 0
sounds,menuResources = {},{}
customCharacters = {}
debuging = false
--Load
function love.load()
	gfx = love.graphics
	setColor,rectangle,getTime,joy,circle = gfx.setColor,gfx.rectangle,love.timer.getTime,love.joystick,gfx.circle
	for i = 1, #worldFiles do
		local func = love.filesystem.load("maps/"..worldFiles[i])
		local env = setfenv(func,{white=white})
		local world = func()
		worlds[i] = world
	end
	local ccs = love.filesystem.getDirectoryItems("customchars")
	for i = 1, #ccs do
		if not ccs[i]:find("ini") then
			local file = love.filesystem.load("customchars/"..ccs[i])
			table.insert(customCharacters,file)
			table.insert(characters,"Custom "..i)
		end
	end
	--load sounds
	sounds.swing = newSound("sounds/punchSwing/swing#.wav",1,1)
	sounds.punchHit = newSound("sounds/punchHit/hit#.wav",1,1)
	sounds.punchHitArmor = newSound("sounds/punchHitArmor/hit#.wav",1,0.9)
	sounds.batHit = newSound("sounds/batHit/hit#.wav",1,1)
	sounds.arrowToWall = newSound("sounds/batHit/hit#.wav",6,0.5)
	sounds.arrowToPlayer = newSound("sounds/batHit/hit#.wav",3,0.6)
	sounds.bowFire = newSound("sounds/batSwing/swing#.wav",2,1)
	sounds.batHitArmor = newSound("sounds/batHitArmor/hit#.wav",1,1)
	sounds.batSwing = newSound("sounds/batSwing/swing#.wav",1,1)
	sounds.jump = newSound("sounds/jump/jump#.wav",0.4,0.6)
	sounds.forceHit = newSound("sounds/forceHit/hit#.wav",1,1)
	sounds.batBreak = newSound("sounds/batBreak/break#.wav",1,1)
	sounds.bowBreak = newSound("sounds/bowBreak/break#.wav",1,1)
	sounds.blood = newSound("sounds/blood/blood#.wav",1,1)
	sounds.breakArmor = newSound("sounds/breakArmor/break#.wav",1,1)
	sounds.jetBoots = newSound("sounds/jetBoots/jet.ogg",1,0.3)
	sounds.music = {} -- musicas
	sounds.music.toPlay = {}
	for i,v in pairs(love.filesystem.getDirectoryItems("music")) do
		if not v:find("ini") then
			local new = {v,love.audio.newSource("music/"..v,"stream"),1}
			--new[2]:setPitch(8)
			new[4] = i
			if v == "District6.ogg" then
				new[3] = 0.25
			elseif v == "hello.mp3" then
				new[3] = 0.75
			elseif v == "loudCore.mp3" then
				new[3] = 0.3
			end
			table.insert(sounds.music,new)
		end
	end
	newSong()
	w,h = gfx.getDimensions()
	fx,fy = 0,0
	rungame,menu,menuCursor,curTime = mode == false,0,1,10
	love.mouse.setVisible(false)
	font18,font36,font108 = gfx.newFont(18),gfx.newFont(36),gfx.newFont(108)
	menuResources.title = gfx.newImage("resources/title.png")
	loadPlayers()
	blood = love.graphics.newParticleSystem(gfx.newImage("resources/pixel.png"),200)
	blood:setParticleLifetime(1)
	blood:setLinearAcceleration(0,20,0,20);
	blood:setSizes(0.3)
	blood:setRotation(0,pi12)
	blood:setSpread(1)
	jetParticles = blood:clone()
	blood:setAreaSpread("uniform",0,0.5)
	blood:setColors(255,0,0,128,255,0, 0, 0)
	jetParticles:setColors(255,200,0,128,255,128,0,96,255,0,0,0)
	jetParticles:setSpin(-0.5*20,0.5*20)
	jetParticles:setSpeed(20)
	jetParticles:setDirection(pi12)
	startTime = getTime()
	menuResources.titleTime,menuResources.renderScale = startTime+6,h/5
end