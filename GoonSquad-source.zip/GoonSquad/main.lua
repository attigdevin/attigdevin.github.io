--[[
Program Details
	Player Variables
		Indexes:
			1 - X position
			2 - Y position
			3 - Joystick
			4 - X velocity
			5 - Y velocity
			6 - In air
		Variables for weapons:
			weaponFired - False if the player is charging
			weaponFire - The time when the weapon is fired
			weaponTimeout - The time when the weapon will next be available
			weapon - The current weapon
			weaponUses - Current # of times the weapon has been used
			breakWeapon - Time in the future when the weapon will be destroyed
			hitSound - Whether or not a hit sound has been played for the current attack
		Taunt Variables: - Note the first and last 0.2s of a taunt lerp to the normal animation.
			taunt - index of taunt animation
			tauntStart - Time when taunt starts
	Frame Variables:
		ra - Right arm rotation
		re - Right elbow rotation
		la - Left arm rotation
		le - Left elbow rotation
		rl - Right leg rotation
		rk - Right knee rotation
		ll - Left leg rotation
		lk - Left knee rotation
		rex - Right arm extension
		lex - Left arm extension
		rotate - Player rotation
		oY - Y value offset
]]
characters = {"Normal","Devin","Thaison","Michael","Chase"}

require "init"
require "render/render"
require "api"
require "tick"
require "control"
require "arrows"
require "drops"


menuItems = {
{name="Respawn",type="button",press=function(pn)
	reset(pn)
	menuOff()
end};
{name="Character",type="rotate",nonStatic=true,values=characters};
{name="Scale",type="slider",scale="log",min=-1,max=1,value=0,inc=0.1};
{name="Music",type="slider",scale="log",min=0,max=1,value=0.05,inc=0.03,change=function(new)
	if maxMusicVolume then
		currentMusic[2]:setVolume(new*currentMusic[3])
	end
end};
{name="Game Mode",type="rotate",values={"Normal","Bows","Hyper"},value="Normal",menuClose=function(new)
	if new ~= gamemode then
		gamemode = new
		if gamemode == "Bows" then
			dropTypes[1][4] = 0
			dropTypes[2][4] = 0
		else
			dropTypes[1][4] = 1
			dropTypes[2][4] = 1
		end
		weighDrops()
		loadWorld(random(1,#worlds))
	end
end};
{name="Respawn All",type="button",press=function(pn)
	reset()
	menuOff()
end};
{name="Quit Game",type="button",press=function(pn)love.event.quit()end};}

function love.resize(nw,nh)
	w,h = nw,nh
end

function love.run()
	love.math.setRandomSeed(os.time())
	random = love.math.random
	love.load()
	love.timer.step()
	local dt = 0
	if true then
		rainbowShader = gfx.newShader[[
			uniform float test;
			#define M_PI 3.1415926535897932384626433832795
			vec3 hsv2rgb(vec3 c){
				vec4 K = vec4(1.0, 2.0 / 3.0, 1.0 / 3.0, 3.0);
				vec3 p = abs(fract(c.xxx + K.xyz) * 6.0 - K.www);
				return c.z * mix(K.xxx, clamp(p - K.xxx, 0.0, 1.0), c.y);
			}
			vec4 effect( vec4 color, Image texture, vec2 texture_coords, vec2 screen_coords ){
				vec4 tru = Texel(texture, texture_coords)*color;
				float v = atan(screen_coords.y-love_ScreenSize.y/2.0,screen_coords.x-love_ScreenSize.x/2.0)/2.0/M_PI;
				vec3 rgb = hsv2rgb(vec3(v+test+(tru.x+tru.y+tru.z)/3.0,1.0,1.0));
				return vec4(rgb.x,rgb.y,rgb.z,tru[3]);
			}]]
	end
	while true do
		love.event.pump()
		for name, a,b,c,d,e,f in love.event.poll() do
			if name == "quit" then
				if not love.quit or not love.quit() then
					return a
				end
			end
			love.handlers[name](a,b,c,d,e,f)
		end
		love.timer.step()
		local dt = love.update(love.timer.getDelta())
		if not wtf then
			gfx.clear(backgroundColor)
		end
		if dope then
			rainbowShader:send("test",curTime/2%1)
		end
		love.draw(dt)
		gfx.present()
	end
end