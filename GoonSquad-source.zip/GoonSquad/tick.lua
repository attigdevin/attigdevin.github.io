function love.update(dt)
	local menuTime = getTime()
	if menuTime-startTime < 20 then -- check up on music
		currentMusic[2]:setVolume((1-math.cos((menuTime-startTime)/20*pi12))*menuItems[4].value*currentMusic[3])
	elseif not maxMusicVolume then
		currentMusic[2]:setVolume(menuItems[4].value*currentMusic[3])
		maxMusicVolume = true
	end
	if not currentMusic[2]:isPlaying() then
		newSong()
	end
	if mode == 2 then
		for _,v in pairs(players) do
			if not v.ready then
				stick = v[3]
				local x = (v.xStickTimeout or 0) < menuTime and normal(stick:getAxis(1)) or 0
				local y = (v.yStickTimeout or 0) < menuTime and normal(stick:getAxis(2)) or 0
				local item,value,index = menuItems[2],v.menuValues[2]
				for i,v in pairs(item.values) do
					if v == value then
						index = i
						break
					end
				end
				local dir
				if x > 0.5 then
					dir = 1
					v.xStickTimeout = menuTime+0.2
				elseif x < -0.5 then
					dir = -1
					v.xStickTimeout = menuTime+0.2
				end
				if dir then
					local new = (index+dir-1)%(#item.values)+1
					v.menuValues[2] = item.values[new]
				end
			end
		end
	end
	if menu ~= 0 then
		local player = players[menu]
		local stick = player[3]
		local x = (player.xStickTimeout or 0) < menuTime and normal(stick:getAxis(1)) or 0
		local y = (player.yStickTimeout or 0) < menuTime and normal(stick:getAxis(2)) or 0
		if y > 0.5 then
			menuCursor = menuCursor+1
			menuCursor = menuCursor > #menuItems and 1 or menuCursor
			player.yStickTimeout = menuTime+0.2
		elseif y < -0.5 then
			menuCursor = menuCursor-1
			menuCursor = menuCursor < 1 and #menuItems or menuCursor
			player.yStickTimeout = menuTime+0.2
		end
		local item = menuItems[menuCursor]
		local value = item.value
		if item.nonStatic then
			value = (players[menu].menuValues)[menuCursor]
		end
		if item.type == "slider" then
			local changed
			if x > 0.5 then
				item.value = item.value+(item.inc or 1)
				player.xStickTimeout = menuTime+0.2
				changed = true
			elseif x < -0.5 then
				item.value = item.value+(item.inc or 1)*-1
				player.xStickTimeout = menuTime+0.2
				changed = true
			end
			item.value = item.value < item.min and item.min or item.value > item.max and item.max or item.value
			if changed and item.change then item.change(item.value)end
		elseif item.type == "rotate" then
			local index
			for i,v in pairs(item.values) do
				if v == value then
					index = i
					break
				end
			end
			local dir
			if x > 0.5 then
				dir = 1
				player.xStickTimeout = menuTime+0.2
			elseif x < -0.5 then
				dir = -1
				player.xStickTimeout = menuTime+0.2
			end
			if dir then
				local new = (index+dir-1)%(#item.values)+1
				if item.nonStatic then
					(players[menu].menuValues)[menuCursor] = item.values[new]
				else
					item.value = item.values[new]
					if item.change then item.change(item.value)end
				end
			end
		end
	end
	if rungame then
		local s = 1
		if slowTimeout > curTime then
			s = s*0.45
		end
		if epicSlow > curTime then
			s = s*0.2
		end
		if love.keyboard.isDown("t") then
			s = s*0.02
		end
		if love.keyboard.isDown("y") then
			s = s*0.2
		end
		if gamemode == "Hyper" then
			s = s*1.3
		end
		if soundSpeed ~= s then
			soundSpeed = s
			for i,v in pairs(sounds) do
				if i ~= "music" then
					local sub = v.subsounds
					if sub then
						for j = 1, #sub do
							local v = sub[j]
							local ss = v.sounds
							for i2 = 1, #ss do
								ss[i2]:setPitch(v.pitch*s)
							end
						end
					else
						local ss = v.sounds
						for i2 = 1, #ss do
							ss[i2]:setPitch(v.pitch*s)
						end
					end
				end
			end
		end
		dt = dt*s
		if dt > 0.04 then
			dt = 0.04 -- if really laggy, slow game down
		end
		curTime = curTime+dt
		local maxX
		local minX
		local fxSum,fySum,alivePlayers = 0,0,0
		for i,player in pairs(players) do -- Physics engine
			if player.health > 0 then
				if not maxX or maxX < player[1] then
					maxX = player[1]
				end
				if not minX or minX > player[1] then
					minX = player[1]
				end
				local stick = player[3]
				alivePlayers = alivePlayers+1 -- Dead guys aren't included in the camera positioning
				local speed = player.speedTimeout > curTime and 1.5 or 1
				local char = player.menuValues[2]
				if char == "Thaison" then -- characters with different speed
					speed = speed*1.3
				end
				if player.armor then
					speed = speed*0.85
				end
				local slowFromWeapon = not player.weaponFired and (player.weapon == "bow" and 0 or 0.6) or 1
				player.crouch = normal(stick:getAxis(2)) > 0.5 and not player[6] and not (player.weapon == "bow" and not player.weaponFired)
				speed = speed*slowFromWeapon -- slow while punching
				if player.crouch then
					speed = speed*0.2 -- slow during crouch
				end
				if player.taunt then
					speed = 0
				end
				local sax,say = player[4],player[5]
				local isJump = stick:isDown(4) or stick:isDown(2)
				player[4] = player[4]*((player[6] and 0.05 or 0.02)^dt) -- x-air resistance, reduced in air because no ground friction
				player[4] = player[4]+normal(stick:getAxis(1))*50*dt*speed -- apply stick movement
				if player[4] ~= 0 then
					player.dir = player[4] > 0 and 1 or -1
					if abs(player[4]) < 0.01 then
						player[4] = 0
					end
				end
				local xve = (player[4]+sax)*0.5
				if xve ~= 0 then -- Don't do anything with the x if it didn't change
					local add = xve*dt
					local goalX = player[1]+add -- Move with the x velocity
					player.walk = (player.walk+abs(add)/6)%1
					local hit = getXCollisions(goalX,player[2],player.dir) -- Check if we smack a wall
					if hit then
						local newGround = getGround(goalX-0.5,player[2]-2,1)
						if not player[6] and newGround+0.5 >= player[2] then -- step up if its only 0.5 greater and on ground
							player[2] = newGround
							player[1] = goalX
						else -- we hit a wall son
							player[1] = hit-0.5*player.dir -- get away from wall
							player[4] = 0
						end
					else
						player[1] = goalX
					end
				end
				if abs(xve) < 1 and player.walk ~= 0 then -- return to idle animation if slow
					if char == "Thaison" then
					else
						if player.walk < 0.25 then
							player.walk = player.walk-dt
						elseif player.walk < 0.5 then
							player.walk = player.walk+dt
							if player.walk > 0.5 then
								player.walk = 0
							end
						elseif player.walk < 0.75 then
							player.walk = player.walk-dt
							if player.walk < 0.5 then
								player.walk = 0
							end
						else
							player.walk = player.walk+dt
						end
						if player.walk < 0 or player.walk >= 1 then
							player.walk = 0
						end
					end
				end
				--player[5] = player[5]*(0.01^dt) -- y air resistance
				if player[6] then -- If we're in the air, apply gravity
					if player.jetbootsTotal --[[and player.jetboots > 0]] then -- jet boot anti gravity
						if player.jetbootSound then -- make sure sound is playing if needed
							if isJump then
								player.jetbootSound:play()
							else
								player.jetbootSound:pause()
							end
						end
						if isJump then
							player[5] = player[5]-(player[5] > 0 and 97 or 80)*dt
							player.jetbootsTotal = player.jetbootsTotal-dt
							if player.jetbootsTotal < 0 then
								player.jetbootSound:stop()
								player.jetboots,player.jetbootsTotal,player.jetbootSound = nil
							elseif pretty and random() < dt*30 then -- throw in some particles
								local side = random() > 0.5 and 1 or -1
								jetParticles:setPosition(player[1]+side*0.4,player[2])
								jetParticles:emit(1)
							end
						end
					else
						if curTime < (player.jumpTimeout+0.1) or ((curTime < (player.jumpTimeout+0.3)) and isJump) then -- anti gravity during a jump
							player[5] = player[5]-50*dt
						end
					end
					player[5] = player[5]+100*dt
				end
				local yve = (player[5]+say)*0.5
				if player[6] then -- Check for hitting head and update y if in the air
					goalY = player[2]+yve*dt
					if yve < 0 then
						local hit = getUpCollisions(player[1],goalY)
						if hit then
							player[2] = hit+2
							player[5] = 0
						else
							player[2] = goalY
						end
					else
						player[2] = goalY
					end
				end
				local air = true
				if yve >= 0 then -- If we aren't rising, then check if player is in the ground
					local ground,thick,effect = getGround(player[1]-0.5,player[2]-2,1) -- Find highest piece that is below line segment
					if ground and player[2] >= ground --[[and player[2]-2 < ground+thick don't think this did anything]] then -- If player is under the surface, reset their velocity and position
						air = false
						if player[6] then
							player.rotate = 0
							player.landTimeout = curTime -- Player just hit the ground
							--[[if player.jetboots then -- reset jetboot time
								player.jetboots = 1
							end]]
						end
						if effect == 0 then -- standing on lava
							damage(player,50*dt)
						end
						player[2] = ground
						player[5] = 0
						if isJump and not player.taunt and not player.crouch and not (player.weapon == "bow" and not player.weaponFired) then -- Activate jump!
							player[5] = (not player.weaponFired and -20 or -25)*(effect == 1 and 1.5 or 1)
							player.jumpTimeout = curTime
							if player.jetbootsTotal then
								if player.jetbootSound then
									player.jetbootSound:rewind()
									player.jetbootSound:play()
								else
									player.jetbootSound = sounds.jetBoots:play()
								end
							else
								sounds.jump:play()
							end
						end
					end
					if player[2] > 50 then
						player.health = 0
						checkWin()
					end
				end
				player[6] = air
				--Check if Devin's charge hitbox must be checked
				local tard = char == "Thaison"
				local punchSpeedMod = tard and 0.6 or 1
				local damageMod = punchSpeedMod*(tard and 1.2 or char == "Michael" and 0.8 or 1)
				local bowSpeedMod = char == "Michael" and 0.8 or 1
				--Check if a punch hitbox must be checked
				local bat = player.weapon == "bat"
				local bow = player.weapon == "bow"
				if bow then
					if player.weaponFire and curTime-player.weaponFire < 0.15*bowSpeedMod and player.weaponFire <= curTime and not player.weaponFired then
						player.weaponFired = true
						player.weaponTimeout = curTime+0.35*bowSpeedMod -- recharge time bow
						local xa,ya = stick:getAxis(1),stick:getAxis(2)
						newArrow(player[1],player[2]-1.5,normal(xa) == 0 and normal(ya) == 0 and (player.dir == -1 and pi or 0) or math.atan2(ya,xa),player)
						sounds.bowFire:play()
						player.weaponUses = player.weaponUses+1
						if (player.weaponUses >= 6 and char ~= "Michael" or player.weaponUses >= 9) and gamemode ~= "Bows" then
							player.breakWeapon = player.weaponFire+0.35*bowSpeedMod
							player.weaponUses = nil
							sounds.bowBreak:play() --play break sound
						end
					end
				elseif bat or not player.weapon then
					if player.weaponFire and curTime-player.weaponFire < 0.15*punchSpeedMod and player.weaponFire <= curTime then
						if not player.weaponFired then
							player.weaponFired = true
							player.weaponTimeout = curTime+0.6*punchSpeedMod -- recharge time for punch/bat
							if bat then
								sounds.batSwing:play()
							else
								sounds.swing:play()
							end
						end
						local dir = player[4] == 0 and player.dir or player[4] < 0 and -1 or 1 -- get which way to face for punch
						local hits = hitPlayers(player[1]+(dir == 1 and 0.4 or (bat and -1.4 or -1.2)),player[2]-1.69+(bat and 0.4 or 0)+(player.crouch and 0.2 or 0),0.8+(player.weapon == "bat" and 0.2 or 0),0.18,player,true) -- Check hit box
						if not player.punchHit then
							player.punchHit = {}
						end
						local hitArmor,hitForce,hit = false
						for _,v in pairs(hits) do
							local yes = true
							for _,v2 in pairs(player.punchHit) do -- check if already hit
								if v2 == v then
									yes = false
								end
							end
							if yes then -- need to apply hit on this player
								hit = true
								if v.forceTimeout > curTime then
									hitForce = true
								elseif v.armor then
									hitArmor = true
								end
								table.insert(player.punchHit,v)
								local power = 2-abs(player[1]-v[1])
								damage(v,(20*(bat and 1.8 or 1)+power*6)*(v.crouch and 0.8 or 1)*damageMod,dir)
								if v.health <= 0 then
									v.health = 0
									deded(v)
									checkWin()
								end
								if bat then
									if not v.armor then
										v.dir = v[4] == 0 and v.dir or v[4] > 0 and 1 or -1
										v[4],v[5] = 0,0
									end
								elseif not v.armor then
									v[4] = v[4]+dir*(12.5+power*20)*(v.crouch and 0.2 or 1)*punchSpeedMod -- knockback
								end
							end
						end
						if hit then -- check for sounds
							if not player.hitSound then
								player.hitSound = true
								if bat then
									if player.menuValues[2] == "Michael" or random() < 1-(0.8^player.weaponUses) then
										player.breakWeapon = player.weaponFire+0.55*punchSpeedMod
										player.weaponUses = nil
										sounds.batBreak:play() --play break sound
									else
										player.weaponUses = player.weaponUses+1
									end
								end
								if hitForce then
									sounds.forceHit:play()
								else
									if bat then
										if hitArmor then
											sounds.batHitArmor:play()
										else
											sounds.batHit:play()
										end
									else
										if hitArmor then
											sounds.punchHitArmor:play()
										else
											sounds.punchHit:play()
										end
									end
								end
							end
						end
					end
				end
				if player.breakWeapon and player.breakWeapon < curTime then
					player.weapon,player.breakWeapon = nil -- break that jizz man
					player.broke = "bow"
				end
				fxSum,fySum = fxSum+player[1],fySum+player[2]-1
			end
		end
		if random() < dt/8*(alivePlayers) then -- spawn a drop
			local num = random(1,#world.drops)
			if not drops[num] then
				local we = random()*totalDropWeight
				local tot = 0
				for i = 1, #dropTypes do
					tot = tot+dropTypes[i][4]
					if we < tot then
						drops[num] = i
						break
					end
				end
			end
		end
		updateArrows(dt)
		local wt = 0.01^dt
		if alivePlayers > 0 then
			if minX and maxX then
			end
			fx,fy = fx*wt+(fxSum/alivePlayers)*(1-wt),fy*wt+(fySum/alivePlayers)*(1-wt)
		end
	else
		dt = 0
	end
	return dt
end