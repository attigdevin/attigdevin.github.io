'''
Non-bouncy numbers
Problem 113

Working from left-to-right if no digit is exceeded by the digit to its left it is called an increasing number; for example, 134468.

Similarly if no digit is exceeded by the digit to its right it is called a decreasing number; for example, 66420.

We shall call a positive integer that is neither increasing nor decreasing a "bouncy" number; for example, 155349.

As n increases, the proportion of bouncy numbers below n increases such that there are only 12951 numbers below one-million that are
not bouncy and only 277032 non-bouncy numbers below 10^10.

How many numbers below a googol (10^100) are not bouncy?
'''


from time import clock
START_TIME = clock()

answer = 0

nCrSums = [0]

POWER = 100

nCrCache = [1]
for i in range(1,POWER+1):
	nCrCache.append(nCrCache[i-1]*(8+i)//i)
for i in range(1,POWER):
	nCrSums.append(nCrSums[i-1]+nCrCache[i])
for n in range(1,POWER+1):
	answer += 2*nCrCache[n]-9+nCrSums[n-1]


print("10**"+str(POWER),answer,clock()-START_TIME)