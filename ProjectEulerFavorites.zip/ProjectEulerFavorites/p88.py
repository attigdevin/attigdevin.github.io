'''
Product-sum numbers
Problem 88

A natural number, N, that can be written as the sum and product of a given set of at least two natural numbers, {a1, a2, ... , ak} is
called a product-sum number: N = a1 + a2 + ... + ak = a1 × a2 × ... × ak.

For example, 6 = 1 + 2 + 3 = 1 × 2 × 3.

For a given set of size, k, we shall call the smallest N with this property a minimal product-sumnumber. The minimal product-sum
numbers for sets of size, k = 2, 3, 4, 5, and 6 are as follows.

k=2: 4 = 2 × 2 = 2 + 2
k=3: 6 = 1 × 2 × 3 = 1 + 2 + 3
k=4: 8 = 1 × 1 × 2 × 4 = 1 + 1 + 2 + 4
k=5: 8 = 1 × 1 × 2 × 2 × 2 = 1 + 1 + 2 + 2 + 2
k=6: 12 = 1 × 1 × 1 × 1 × 2 × 6 = 1 + 1 + 1 + 1 + 2 + 6

Hence for 2≤k≤6, the sum of all the minimal product-sum numbers is 4+6+8+12 = 30; note that 8 is only counted once in the sum.

In fact, as the complete set of minimal product-sum numbers for 2≤k≤12 is {4, 6, 8, 12, 15, 16}, the sum is 61.

What is the sum of all the minimal product-sum numbers for 2≤k≤12000?
'''


from funcs import primes
from time import clock
START_TIME = clock()

LIMIT = 13000

M = 12000

ps = primes(LIMIT)
primeSet = set(ps)
divs = [0,0]
vs = [0,0]
kValues = dict()
for n in range(2,LIMIT):
	v = {n-1}
	if n in primeSet:
		div = {n}
	else:
		for p in ps:
			if n%p == 0:
				break
		d = n//p
		ddiv = divs[d]
		div = ddiv.copy()
		div.add(p)
		for j in ddiv:
			div.add(j*p)
		for d in div:
			d2 = n//d
			if d2 >= d:
				for v1 in vs[d]:
					for v2 in vs[d2]:
						v.add(v1+v2)
	vs.append(v)
	divs.append(div)
	for i in v:
		j = n-i
		if j not in kValues:
			kValues[j] = n
i = 2
s = set()
while True:
	if i > M:
		break
	if i in kValues:
		s.add(kValues[i])
	else:
		print("Limit too small")
		break
	i += 1

print(sum(s),clock()-START_TIME)