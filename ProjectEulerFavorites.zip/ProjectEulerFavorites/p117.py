'''
Red, green, and blue tiles
Problem 117

Using a combination of black square tiles and oblong tiles chosen from: red tiles measuring two units, green tiles measuring three units,
and blue tiles measuring four units, it is possible to tile a row measuring five units in length in exactly fifteen different ways.

How many ways can a row measuring fifty units in length be tiled?
'''

from time import clock
from functools import reduce
from math import factorial

START_TIME = clock()

answer = 0

length = 50

lengths = [2,3,4]

m = 0

counts = [0]*len(lengths)

blacks = length

broke = True

while broke:
	broke = False
	for i,l in enumerate(lengths):
		if blacks < l:
			blacks += counts[i]*lengths[i]
			counts[i] = 0
		else:
			blacks -= lengths[i]
			counts[i] += 1
			broke = True
			break
	answer += factorial(blacks+sum(counts))//reduce(lambda x,y: x*y,map(factorial,[blacks]+counts))

print(answer,clock()-START_TIME)