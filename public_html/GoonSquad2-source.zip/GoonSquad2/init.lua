state = 0	-- 0 = Title; 1 = Main Menu; 2 = Character Select; 3 = Game; 4 = Connecting to Server; 5 = Opening server;
			-- 6 hole punching client; 7 settings menu
love.filesystem.setIdentity("GoonSquad2")
startDelta = 0
players = {}
gameTime = 0 -- time since last startGame call. Stops during pause
showFPS,debugMode = true,false -- show FPS
defaultWalkSpeed = 60
gravity = -35
xGroundResistance = 0.005
xAirResistance = 0.02
jumpTimeout,punchTimeout,punchDelay,kickTimeout,kickDelay,swordTimeout,swordDelay = 0.175,0.4,0.15,0.2,0.11,0.5,0.4
jetpackFuel = 8
speedDropDuration = 5
punchPercentStart = 0.5 -- when the second punching frame takes over from the first
kickPercentStart = 0.7 -- when the second kicking frame takes over from the first
swordPercentStart = 0.7
jumpVelocity = 15
worlds = {}
maxPlayers = 8
inGameMenu = 0
d25 = true
pi = math.pi
pi2 = pi*2
keyboardConfigs = {
{"w","a","s","d","space","lshift","e",name="Keyboard Config 1"};
{"kp8","kp4","kp5","kp6","kpenter","kp+","kp9",name="Keyboard Config 2"};
}
if true then
	local oldRectangle = love.graphics.rectangle
	local oldColor = love.graphics.setColor
	local shift = 0.2
	local currentColor
	love.graphics.setColor = function(...)
		currentColor = {...}
		oldColor(...)
	end
	love.graphics.rectangle = function(f,x,y,w,h)
		if d25 then
			if w < 0 then
				x = x+w
				w = -w
			end
			if h < 0 then
				y = y+h
				h = -h
			end
			local newColor = currentColor
			if #currentColor == 1 then
				newColor = {newColor[1][1]-100,newColor[1][2]-100,newColor[1][3]-100}
			else
				newColor = {newColor[1]-100,newColor[2]-100,newColor[3]-100}
			end
			oldColor(newColor)
			love.graphics.polygon("fill",x,y+h,x+shift,y+h+shift,x+w+shift,y+h+shift,x+w,y+h)
			newColor = {newColor[1]-50,newColor[2]-50,newColor[3]-50}
			oldColor(newColor)
			love.graphics.polygon("fill",x+w,y+h,x+w+shift,y+h+shift,x+w+shift,y+shift,x+w,y)
			oldColor(unpack(currentColor))
		end
		oldRectangle(f,x,y,w,h)
	end
end

local loadStage = require"stages/stageloader"

love.mouse.setVisible(false)
worlds[1] = loadStage("builder.lua")
love.math.setRandomSeed(os.time())
random = love.math.random
math.random = love.math.random
aspectRatio = w/h
local fontsToLoad = {12,14,18,24,32,36,48,54,144}
fonts = {}
for i = 1, #fontsToLoad do
	local n = fontsToLoad[i]
	fonts["p"..n] = gfx.newFont(n)
end

return function(args)
	if args[2] and args[2] ~= "" then
		print(args[2])
		worlds[1] = loadStage(args[2])
		startGame()
	end
end