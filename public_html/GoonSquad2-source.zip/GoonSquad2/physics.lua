local playerWidth = 1
local speedDropSpeedModifier = 1.3
local airSpeedModifier = 0.8
local playerHeight = 2
local swordSpeedModifier = 0.85
local joystickMax = 0.8 -- x-axis reaches top speed when it is at least 0.8
local joystickDead = 0.1 -- axis's read as 0 if they're less than 0.2
local joystickDist = joystickMax-joystickDead

local function getGround(x,y)
	x = x-playerWidth/2
	local ph = world.physics
	local height
	for i = 1, #ph do
		local o = ph[i]
		if (o[1] < x+playerWidth and o[3] > x) -- aligned with x's
			and (y+playerHeight > o[4]) -- and below current y
			and (not height or height < o[2]) then
			height = o[2]
		end
	end
	return height
end
local function joystickZoneCorrection(input)
	local a = math.abs(input)
	if a < joystickDead then
		return 0
	elseif a > joystickMax then
		return input > 0 and 1 or -1
	elseif input > 0 then
		return (input-joystickDead)/joystickDist
	else
		return (input+joystickDead)/joystickDist
	end
end
local function getUpCollisions(x,y)
	local ph = world.physics
	local ty = y+playerHeight
	local xl,xr = x-playerWidth/2,x+playerWidth/2
	local worst
	for i = 1, #ph do
		local o = ph[i]
		if (o[1] < xr and o[3] > xl) -- aligned with x's
			and (o[2] > y and o[4] < ty) -- inside of part of the ceiling
			and (not worst or worst > o[4]) then
			worst = o[4]
		end
	end
	return worst and worst-playerHeight
end
local function checkWalls(x,y,isRight)
	local ph = world.physics
	local ty = y+playerHeight
	local xl,xr = x-playerWidth/2,x+playerWidth/2
	local worst
	if isRight then
		for i = 1, #ph do
			local o = ph[i]
			if (o[2] > y and o[4] < ty) -- aligned with y's
				and (o[1] < xr and o[3] > xl) -- inside of part of the wall
				and (not worst or worst > o[1]) then
				worst = o[1]
			end
		end
		return worst and worst-playerWidth/2
	else
		for i = 1, #ph do
			local o = ph[i]
			if (o[2] > y and o[4] < ty) -- aligned with y's
				and (o[1] < xr and o[3] > xl) -- inside of part of the wall
				and (not worst or worst < o[3]) then
				worst = o[3]
			end
		end
		return worst and worst+playerWidth/2
	end
end

function sign(x)
	return x < 0 and -1 or x > 0 and 1 or 0
end

local maxXV = 0

return function(dt)
	for playerNumber,player in pairs(players) do
		local joystick = player.joystick
		local pxv,pyv = player.xv,player.yv -- save starting velocity for position calculations later
		player.xv = player.xv*(player.grounded and xGroundResistance or xAirResistance)^dt
		local moveInput = joystickZoneCorrection(joystick:getAxis(1))
		if player.swordStart then
			if sign(moveInput) == -player.direction then
				moveInput = 0
			end
		end
		player.xv = player.xv+moveInput*dt*defaultWalkSpeed*(player.speedDrop and speedDropSpeedModifier or 1)*(player.grounded and 1 or airSpeedModifier)*(player.sword and swordSpeedModifier or 1) -- apply stick effect
		player.walkingAnim = player.walkingAnim+math.abs(moveInput*dt*defaultWalkSpeed)*0.015
		if moveInput ~= 0 then
			player.direction = moveInput > 0 and 1 or -1
		end
		local xv = (player.xv+pxv)/2
		if xv ~= 0 then
			local m = player.xv*dt
			player.walkingAnim = player.walkingAnim+math.abs(m)*0.12
			player.x = player.x+m
			local nx = checkWalls(player.x,player.y,xv > 0)
			if nx then
				local newGround = getGround(player.x,player.y)
				if player.grounded and newGround-player.y <= 0.5 then -- step assist
					player.y = newGround
				else
					player.x = nx
					player.xv = 0
				end
			end
		end
		local ground = getGround(player.x,player.y)
		player.grounded = ground == player.y
		if not player.grounded or pyv > 0 then -- don't do y velocity crap if the player is on the ground anyways
			local useJetpack = player.jetpack and joystick:isDown(5)
			if useJetpack and onlineMode ~= 2 then -- client doesn't do jetpack fuel
				player.jetpack = player.jetpack-dt
				if player.jetpack < 0 then player.jetpack = nil end
			end
			local force = useJetpack and (player.yv > 10 and -10 or player.yv > 0 and 10 or 30)-gravity or 0
			player.yv = player.yv+(force+gravity)*dt -- gravity is negative dw
			local yv = (player.yv+pyv)/2
			player.y = player.y+yv*dt
			if yv < 0 then
				if ground and player.y < ground then
					player.y = ground
					player:land()
				end
			else
				player.grounded = false
				local hit = getUpCollisions(player.x,player.y)
				if hit then
					player.yv = 0
					player.y = hit
				end
			end
		end
	end
end
