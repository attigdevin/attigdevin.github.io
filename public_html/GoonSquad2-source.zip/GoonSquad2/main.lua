gfx = love.graphics
w,h = gfx.getDimensions()
require"api"
local init = require"init"
local tick = require"tick"
colors = require"colors"
sounds = require"sounds/sound"
require"input"

function love.resize(wi,he)
	w,h = wi,he
	aspectRatio = w/h
end
function update(dt)
	local dtMod = 1
	if love.keyboard.isDown("t") then dtMod = dtMod*0.05 end
	dt = dt*dtMod
	if dtMod ~= sounds.soundSpeed then
		sounds.setSpeed(dtMod)
	end
	tick(dt)
end
function love.run()
	init(arg)
	love.timer.step()
	local dt = 0
	while true do
		if love.event then
			love.event.pump()
			for name, a,b,c,d,e,f in love.event.poll() do
				if name == "quit" then
					return a
				end
				love.handlers[name](a,b,c,d,e,f)
			end
		end
		love.timer.step()
		update(love.timer.getDelta())
	end
end