local Particles = require"render/particles"
local dropRate = 5

local circleGradientShader = gfx.newShader([[
varying vec2 vpos;
vec4 position(mat4 transform_projection, vec4 vertex_position)
{
	vpos = vec2(vertex_position);
    return transform_projection * vertex_position;
}]],[[
varying vec2 vpos;
extern vec2 c;
extern float r;
extern vec3 c2;
vec4 effect(vec4 color, Image texture, vec2 texture_coords, vec2 screen_coords)
{
	float a = distance(vpos,c)/r;
    return vec4(vec3(color)*(1.0-a)+c2*a,1.0);
}
]])

local lightningVerts = {36,4,12,16,18,21,4,36,28,24,22,19}
for i = 1, #lightningVerts do
	lightningVerts[i] = (lightningVerts[i]/40-0.5)*((i+1)%2*2-1)
end
local lt = love.math.triangulate(lightningVerts)
local mt = {}
for i = 1, #lt do
	local t = lt[i]
	for i2 = 1, #t,2 do
		table.insert(mt,{t[i2],t[i2+1]})
	end
end
lt = nil
local lightningMesh = gfx.newMesh(mt,"triangles","static")
local lightningBuildup = 0

local swordMesh = require"render/meshes/sword"
local jetpackMesh = require"render/meshes/jetpack"


local Drops
Drops = {
{
render=function()
	gfx.setLineWidth(0.05)
	gfx.setShader(circleGradientShader)
	circleGradientShader:sendColor("c2",{255,128,0})
	circleGradientShader:send("r",0.35)
	gfx.setColor(255,255,255)
	gfx.circle("fill",0,0,0.35,20)
	gfx.setShader()
	gfx.setColor(0,0,0)
	gfx.circle("line",0,0,0.35,20)
	gfx.setColor(255,255,0)
	gfx.draw(lightningMesh)
	gfx.setColor(0,0,0)
	gfx.polygon("line",lightningVerts)
end;
pickup=function(v)
	v.speedDrop = gameTime
	return true
end;
name="Speed";
};
{
render=function()
	gfx.setLineWidth(0.05)
	gfx.setShader(circleGradientShader)
	circleGradientShader:sendColor("c2",{192,0,0})
	circleGradientShader:send("r",0.35)
	gfx.setColor(0,0,0)
	gfx.circle("fill",0,0,0.35,20)
	gfx.setShader()
	gfx.setColor(0,0,0)
	gfx.circle("line",0,0,0.35,20)
	gfx.setColor(255,255,255)
	gfx.rotate(gameTime)
	gfx.scale(0.7)
	gfx.draw(swordMesh,0,-0.4)
end;
pickup=function(v)
	if not v.sword then
		v.sword = gameTime
		return true
	end
end;
name="Sword";
weight=0.2;
};
{
render=function()
	gfx.setLineWidth(0.05)
	gfx.setShader(circleGradientShader)
	circleGradientShader:sendColor("c2",{50,100,240})
	circleGradientShader:send("r",0.45)
	gfx.setColor(20,20,20)
	gfx.circle("fill",0,0,0.45,20)
	gfx.setShader()
	gfx.setColor(0,0,0)
	gfx.circle("line",0,0,0.45,20)
	local d = 0.075
	gfx.rotate(gameTime)
	gfx.setColor(255,255,255)
	gfx.draw(jetpackMesh,d,-0.08)
	gfx.draw(jetpackMesh,-d,-0.08)
end;
pickup=function(v)
	v.jetpack = jetpackFuel
	return true
end;
name="Jetpack";
};
renderDrops=function(cx,cy,width,height)
	width,height = width+1,height+1
	local drops = world.drops
	if drops then -- can remove this later
		local currentDrops = worldState.drops
		for i = 1, #currentDrops do
			local d = currentDrops[i]
			if d ~= 0 then
				local x,y = drops[i][1],drops[i][2] -- check this out for an error with server thingy
				if y < cy+height/2 and y > cy-height/2 and x < cx+width/2 and x > cx-width/2 then
					gfx.push()
					gfx.translate(x,y)
					Drops[d].render()
					gfx.pop()
				end
			end
		end
	end
end;
tickDrops=function(dt)
	if onlineMode ~= 2 then -- don't spawn or check drops on client
		if math.random() < dt/dropRate or love.keyboard.isDown("3") then
			Drops.spawnDrop()
		end
		for i = 1, #worldState.drops do
			local d = worldState.drops[i]
			if d ~= 0 then
				local wd = world.drops[i]
				for _,v in pairs(players) do
					if rectCollide(v.x-0.5,v.y,1,2,wd[1]-0.5,wd[2]-0.5,1,1) then
						if Drops[d].pickup(v) then
								worldState.drops[i] = 0
							break
						end
					end
				end
			end
		end
	end
	lightningBuildup = lightningBuildup+dt
	local doLightning
	if lightningBuildup > 0.3 then
		lightningBuildup = lightningBuildup-0.3
		doLightning = true
	end
	for i,v in pairs(players) do
		if v.speedDrop then
			local sDt = gameTime-v.speedDrop
			if sDt >= speedDropDuration then
				v.speedDrop = nil
			elseif doLightning then
				Particles.addLightningParticle(v.x,v.y+10,v.x,v.y)
			end
		end
	end
end;
spawnDrop = function()
	local n = #worldState.drops
	if n > 0 then
		local i = math.random(1,#worldState.drops)
		if worldState.drops[i] == 0 then
			local d = math.random()*Drops.totalWeight
			local weightSum = 0
			for j = 1, #Drops do
				weightSum = weightSum+(Drops[j].weight or 1)
				if weightSum >= d then
					worldState.drops[i] = j
					break
				end
			end
		end
	end
end;
totalWeight = 0;
}

for i = 1, #Drops do
	Drops.totalWeight = Drops.totalWeight+(Drops[i].weight or 1)
end

return Drops