local stepPhysics = require"physics"
local Server,Client = require"network/server",require"network/client"
local Drops = require"drops"
local draw = require"render/draw"
local Attack = require"attack"

local bleedDamage = 5
local heal = 1
local bloodBuildup = 0
local bloodParticleRate = 1/30

return function(dt)
	startDelta = startDelta+dt
	if state == 3 then
		if inGameMenu == 0 or onlineMode ~= 0 then
			gameTime = gameTime+dt
			bloodBuildup = bloodBuildup+dt
			local doBloodParticles
			if bloodBuildup > bloodParticleRate then
				bloodBuildup = bloodBuildup-bloodParticleRate
				doBloodParticles = true
			end
			for playerNumber,player in pairs(players) do
				if player.y < -50 then
					player:damage(100)
				end
				if player.health > 0 then -- alive
					player.health = player.health+dt*heal
					if player.health > player.maxHealth then
						player.health = player.maxHealth
					end
					if player.joystick:isDown(5) then
						player:press(5)
					end
					if player.joystick:isDown(6) then
						--player:press(6)
					end
					if player.bleeding then
						player.bleeding = player.bleeding-dt
						if doBloodParticles then
							player:bleed(-math.pi/2,1,2)
						end
						if player.bleeding < 0 then
							player:damage((player.bleeding+dt)*bleedDamage)
							player.bleeding = nil
						else
							player:damage(dt*bleedDamage)
						end
					end
					Attack.tick(player)
				end
			end
			Drops.tickDrops(dt)
			stepPhysics(dt)
		else
			dt = 0
		end
		if onlineMode == 2 then
			Client.tickClient(dt)
		elseif onlineMode == 1 then
			Server.tickServer(dt)
		end
	end
	if state == 4 or state == 6 then
		Client.tickClient(dt)
	end
	if state == 5 then
		Server.tickServer(dt)
	end
	draw(dt)
end