require"stages/xml"
require"stages/handler"
local xmlhandler = simpleTreeHandler()
local parser = xmlParser(xmlhandler)

local function parseStyle(style)
	local o = {}
	for i in string.gmatch(style, "[^;]+") do
		local key,value = i:match("(.-):(.*)")
		o[key] = value
	end
	return o
end
local hexValues = {}
for i = 0, 15 do
	hexValues[i < 10 and tostring(i) or string.char(55+i)] = i
end
local function hexPairToByte(s)
	return hexValues[s:sub(1,1)]*16+hexValues[s:sub(2,2)]
end
local function hexToRGB(s)
	s = s:upper()
	if s:sub(1,1) == "#" then
		s = s:sub(2)
	end
	return {hexPairToByte(s:sub(1,2)),hexPairToByte(s:sub(3,4)),hexPairToByte(s:sub(5,6))}
end
local function round(v,r)
	return math.floor(v/r+0.5)*r
end
return function(filename)
	if filename:sub(-3,-1) == "lua" then
		return loadstring(love.filesystem.read("stages/stages/"..filename))()
	else
		local world = {physics={},render={}}
		local data = love.filesystem.read("stages/stages/"..filename)
		parser:parse(data)
		local svg = xmlhandler.root.svg[1]
		local rects = svg.rect
		if rects then
			for i = 1, #rects do
				local r = rects[i]._attr
				local style = parseStyle(r.style)
				if r["inkscape:label"] == "background" then
					world.backgroundColor = hexToRGB(style.fill)
				else
					local transform = r.transform
					local xt,yt = transform:match("scale%((.-),(.-)%)")
					if xt and yt then
						xt,yt = tonumber(xt),tonumber(yt)
						r.width,r.x = r.width*xt,r.x*xt
						r.height,r.y = -r.height*yt,-r.y*yt
					end
					local w,h,x,y = round(r.width,0.5),round(r.height,0.5),round(r.x,0.5)-svg._attr.width/2,round(r.y,0.5)+svg._attr.height/2 -- note, x,y is the lower left corner, this can be confusing
					if r.physics ~= "false" then
						table.insert(world.physics,{x,y+h,x+w,y})
					end
					if r.visible ~= "false" then
						table.insert(world.render,{hexToRGB(style.fill),0,x,y,w,h})
					end
				end
			end
		end
		return world
	end
end