return {white={255,255,255},black={0,0,0},defaultBackgroundColor={50,50,50};
menuBackground={237,151,25};settingsMenu={255,100,94};debugColor1={128,192,255};

playerColors={
{192,64,64},{64,96,192},{192,192,64},{64,192,64},
{192,128,64},{64,192,192},{128,64,192},{192,128,192}
}

}