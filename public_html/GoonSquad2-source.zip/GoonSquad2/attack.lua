local punchKnockback,kickKnockback,swordKnockback = 25,20,5
local punchDamage,kickDamage,swordDamage = 25,20,30
local swordHitboxStart = 0.8
local punchHitboxStart = 0.7
local swordBleedTime = 7
local kickHitboxStart = 0.8
local Attack

local function checkBox(exclude,x,y,w,h,r)
	if w < 0 then
		w = -w
		x = x-w
	end
	if h < 0 then
		h = -h
		y = y-h
	end
	local hit = {}
	for i,player in pairs(players) do
		if player ~= exclude and player.x-0.5 < x+w and player.x+0.5 > x and player.y < y+h and player.y+2 > y then
			table.insert(hit,player)
		end
	end
	return hit
end
local function rectangleLineCollision(x,y,w,h,x1,y1,x2,y2)
	local p1,p2 = {x1,y1},{x2,y2}
	local function F(x,y)
		return (y2-y1)*x+(x1-x2)*y+(x2*y1-x1*y2)
	end
	local pos = 0
	local neg = 0
	local vals = {F(x,y),F(x+w,y),F(x,y+h),F(x+w,y+h)}
	for i = 1, #vals do
		local v = vals[i]
		if v == 0 then
			return true
		elseif v < 0 then
			neg = neg+1
		else
			pos = pos+1
		end
	end
	if pos > 0 and neg > 0 then
		local xTR,xBL,yTR,yBL = x+w,x,y+h,y
		return not (x1 > xTR and x2 > xTR) and not (x1 < xBL and x2 < xBL) and not (y1 > yTR and y2 > yTR) and not (y1 < yBL and y2 < yBL)
	end
end
local function checkLinebox(exclude,x1,y1,x2,y2)
	local hit = {}
	for i,player in pairs(players) do
		if player ~= exclude and rectangleLineCollision(player.x-0.5,player.y,1,2,x1,y1,x2,y2) then
			table.insert(hit,player)
		end
	end
	return hit
end

local function fire(player,t,final) -- t:0 = punch t:1 = kick
	local hit
	if t == 0 then
		if final then
			player.punchStart,player.punchSoundPlayed = nil
			player.punchThrow = gameTime
		end
		hit = checkBox(player,Attack.getPunchHitbox(player))
	elseif t == 1 then
		if final then
			player.kickStart,player.kickSoundPlayed = nil
			player.kickThrow = gameTime
		end
		hit = checkBox(player,Attack.getKickHitbox(player))
	elseif t == 2 then
		if final then
			player.swordStart,player.swordSoundPlayed = nil
			player.swordThrow = gameTime
		end
		hit = checkLinebox(player,Attack.getSwordHitbox(player))
	end
	if not player.hitList then
		player.hitList = {}
	end
	local alreadyHit
	for i,v in pairs(player.hitList) do
		alreadyHit = true
		break
	end
	local hitOne
	for i = 1, #hit do
		local h = hit[i]
		if not player.hitList[h] then
			hitOne = true
			player.hitList[h] = true
			h.xv = h.xv+(t == 0 and punchKnockback or t == 1 and kickKnockback or t == 2 and swordKnockback)*player.direction
			h:bleed(t == 2 and (player.direction == 1 and -math.pi/4 or math.pi*5/4) or (player.direction == 1 and 0 or math.pi),t == 2 and 20 or 10,t == 2 and 10 or 30)
			if t == 2 then
				h:bleedTime(swordBleedTime)
			end
			h:damage(t == 0 and punchDamage or t == 1 and kickDamage or t == 2 and swordDamage)
		end
	end
	if not alreadyHit and hitOne then
		sounds.punchHit:play()
	end
end

Attack = {
tick=function(player)
	if player.swordStart then
		local swordDt = (gameTime-player.swordStart)/swordDelay
		if swordDt >= swordPercentStart and not player.swordSoundPlayed then
			player.swordSoundPlayed = true
			sounds.swordSwing:play()
		end
		if swordDt >= 1 and not player.swordThrow then
			fire(player,2,true)
		elseif swordDt >= swordHitboxStart then
			fire(player,2)
		end
	end
	if player.punchStart then
		local punchDt = (gameTime-player.punchStart)/punchDelay
		if punchDt >= punchPercentStart and not player.punchSoundPlayed then
			player.punchSoundPlayed = true
			sounds.punchSwing:play()
		end
		if punchDt >= 1 and not player.punchThrow then
			fire(player,0,true)
		elseif punchDt >= punchHitboxStart then -- during last 10% it will check the hit frames
			fire(player,0)
		end
	end
	if player.kickStart then
		local kickDt = (gameTime-player.kickStart)/kickDelay
		if kickDt >= kickPercentStart and not player.kickSoundPlayed then
			player.kickSoundPlayed = true
			sounds.kickSwing:play()
		end
		if kickDt >= 1 and not player.kickThrow then
			fire(player,1,true)
		elseif kickDt >= kickHitboxStart then -- during last 10% it will check the hit frames
			fire(player,1)
		end
	end
end;
swordHitboxActive = function(player)
	return player.swordStart and (gameTime-player.swordStart)/swordDelay >= swordHitboxStart
end;
getSwordHitbox = function(player)
	local a = player.swordStart and ((gameTime-player.swordStart)/swordDelay-swordHitboxStart)/(1-swordHitboxStart) or 1
	local dir = 2.636-a*2.438
	local x,y = player.x+(math.cos(dir-0.5)*0.5+0.7-a*1)*player.direction,(player.y+1)+math.sin(dir-0.5)*0.5
	local length = 1.2
	return x,y,x+math.cos(dir)*length*player.direction,y+math.sin(dir)*length
end;
drawSwordBox = function(player)
	if Attack.swordHitboxActive(player) then
		gfx.setLineWidth(0.05)
		gfx.line(Attack.getSwordHitbox(player))
	end
end;
punchHitboxActive = function(player)
	return player.punchStart and (gameTime-player.punchStart)/punchDelay >= punchHitboxStart
end;
getPunchHitbox = function(player)
	local a = player.punchStart and ((gameTime-player.punchStart)/punchDelay) or 1
	return player.x+(0.3+a-1)*player.direction,player.y+0.225+1.225-0.1+(a-1),0.65*player.direction,0.2
end;
drawPunchBox = function(player)
	if Attack.punchHitboxActive(player) then
		gfx.rectangle("fill",Attack.getPunchHitbox(player))
	end
end;
kickHitboxActive = function(player)
	return player.kickStart and (gameTime-player.kickStart)/kickDelay >= kickHitboxStart
end;
getKickHitbox = function(player)
	return player.x+0.35*player.direction,player.y+0.2,0.65*player.direction,0.3
end;
drawKickBox = function(player)
	if Attack.kickHitboxActive(player) then
		gfx.rectangle("fill",Attack.getKickHitbox(player))
	end
end;
}
return Attack