-- Movement = inputs 1-4
-- Jump = input 5
-- Attack = input 6
-- Start = input 7
-- D-Pad = inputs 8-11

local keyboardMetatable = {__index = {
	isDown = function(t,inputNumber)
		return love.keyboard.isDown(t[inputNumber])
	end;
	getAxis = function(t,axis)
		if axis == 1 then
			local out = 0
			if love.keyboard.isDown(t[2]) then
				out = out-1
			end
			if love.keyboard.isDown(t[4]) then
				out = out+1
			end
			return out
		elseif axis == 2 then
			local out = 0
			if love.keyboard.isDown(t[1]) then
				out = out-1
			end
			if love.keyboard.isDown(t[3]) then
				out = out+1
			end
			return out
		end
	end;
	getName = function(t)
		return t.name
	end;
}}
for i = 1, #keyboardConfigs do
	setmetatable(keyboardConfigs[i],keyboardMetatable)
end
local function stepCursor(n,options,inputNumber)
	if inputNumber == 8 then
		n = n-1
	elseif inputNumber == 10 then
		n = n+1
	end
	n = (n-1)%#options+1
	if inputNumber == 5 or inputNumber == 6 then
		if options == settingsOptions then
			settingsActivated()
		else
			options[n][2]()
		end
	end
	return n
end
local function inputDown(inputNumber,joystick)
	if state == 0 then
		mainMenu()
	elseif state == 1 then
		menuCursor = stepCursor(menuCursor,menuOptions,inputNumber)
	elseif state == 7 then
		settingsCursor = stepCursor(settingsCursor,settingsOptions,inputNumber)
	elseif inputNumber and (state == 2 or state == 3) then
		if inputNumber == 7 then
			local alreadyIn = false
			for i,p in pairs(players) do
				if p.joystick == joystick then
					alreadyIn = i
				end
			end
			if not alreadyIn then
				if inGameMenu == 0 then
					addPlayer(joystick)
					return
				end
			else
				if inGameMenu == 0 then
					openSettings(alreadyIn)
				elseif inGameMenu == alreadyIn then
					closeSettings()
				end
			end
		else
			if inGameMenu == 0 or onlineMode ~= 0 then
				if joystick ~= nil then
					for i,p in pairs(players) do
						if p.joystick == joystick and i ~= inGameMenu then
							p:press(inputNumber)
						end
					end
				end
			end
			if inGameMenu ~= 0 then
				if players[inGameMenu] and players[inGameMenu].joystick == joystick then
					settingsCursor = stepCursor(settingsCursor,settingsOptions,inputNumber)
				end
			end
		end
	end
end

local joystickButtonMap = {[10]=7,[2]=5,[8]=6,[3]=6}
local myJoysticks = {}
local joyMetatable = {__index={
	isDown = function(t,inputNumber)
		for i,v in pairs(t.map) do
			if v == inputNumber then
				if t.love2dJoystick:isDown(i) then
					return true
				end
			end
		end
		return false
	end;
	getAxis = function(t,axis)
		return t.love2dJoystick:getAxis(axis)
	end;
	getName = function(t)
		return t.love2dJoystick:getName()
	end;
}}

function love.joystickhat(love2dJoystick,hat,direction)
	local joystick = myJoysticks[love2dJoystick]
	if direction == "u" then
		inputDown(8,joystick)
	elseif direction == "l" then
		inputDown(9,joystick)
	elseif direction == "d" then
		inputDown(10,joystick)
	elseif direction == "r" then
		inputDown(11,joystick)
	end
end

function love.joystickadded(joystick)
	local myJoystick = {love2dJoystick=joystick,map=joystickButtonMap}
	setmetatable(myJoystick,joyMetatable)
	myJoysticks[joystick] = myJoystick
end

function love.joystickremoved(joystick)
	myJoysticks[joystick] = nil
end

function love.joystickpressed(love2dJoystick,button)
	local joystick = myJoysticks[love2dJoystick]
	if not joystick then error("Joystick not found") end
	local o = joystickButtonMap[button]
	if o then
		inputDown(o,joystick)
		return
	end
	inputDown()
end

function love.keypressed(key)
	if key == "escape" then
		if state == 1 then
			love.event.quit()
			return
		else
			mainMenu()
		end
	elseif key == "1" then
		debugMode = not debugMode
	elseif key == "2" then
		gfx.newScreenshot():encode("png",math.floor(love.timer.getTime())..".png")
	end
	for i = 1, #keyboardConfigs do
		local c = keyboardConfigs[i]
		for i2 = 1, #c do
			if c[i2] == key then
				if i2 > 4 then -- the first 4 keys only provide inputs for the analog stick, these are translated to the dpad
					inputDown(i2,c)
					return
				else
					inputDown(i2+7,c)
					return
				end
				break
			end
		end
	end
	inputDown()
end