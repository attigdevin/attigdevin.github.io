local soundSpeed = 1
local soundVolume = 1

local soundMeta = {__index={play=function(self,pitch,volume) -- pitch and volume change per play not fully supported yet
	if self.subsounds then
		self = self.subsounds[random(1,#self.subsounds)]
	end
	local volume,pitch = volume or 1,pitch or 1
	local sounds = self.sounds
	for i = 1, #sounds do
		local v = sounds[i]
		if not v:isPlaying() and not v:isPaused() then
			v:setVolume(volume*self.volume*soundVolume)
			v:setPitch(pitch*self.pitch*soundSpeed)
			v:play()
			return v
		end
	end
	local new = sounds[1]:clone()
	table.insert(sounds,new)
	new:setVolume(volume*self.volume)
	new:setPitch(self.pitch*soundSpeed)
	new:play()
	return new
end,update=function(self)
	if self.subsounds then
		for i = 1, #self.subsounds do
			self.subsounds[i]:update()
		end
	else
		local sounds = self.sounds
		for i = 1, #sounds do
			local v = sounds[i]
			v:setVolume(self.volume*soundVolume)
			v:setPitch(self.pitch*soundSpeed)
		end
	end
end}}

local loaded = {}

local function newSound(source,pitch,volume)
	pitch = pitch or 1
	volume = volume or 1
	if source:find("#") then
		local sound = {subsounds={}}
		i = 1
		while true do
			local s = source:gsub("#",i)
			if love.filesystem.isFile(s) then
				sound.subsounds[i] = newSound(s,pitch,volume)
			else
				break
			end
			i = i+1
		end
		setmetatable(sound,soundMeta)
		return sound
	else
		local s
		if loaded[source] then
			s = loaded[source]:clone()
		else
			s = love.audio.newSource(source,"static")
			loaded[source] = s
		end
		local sound = {pitch=pitch,volume=volume,sounds={s}}
		s:setPitch(pitch)
		s:setVolume(volume)
		setmetatable(sound,soundMeta)
		return sound
	end
end

local sounds = {
punchHit = newSound("sounds/punchHit/hit#.wav");
punchSwing = newSound("sounds/punchSwing/swing#.wav");
swordSwing = newSound("sounds/punchSwing/swing#.wav");
kickSwing = newSound("sounds/punchSwing/swing#.wav",1.6);
}
local Sound
Sound = {soundSpeed=soundSpeed,setSpeed=function(x)
	soundSpeed = x
	Sound.soundSpeed = x
	for i,v in pairs(sounds) do
		v:update()
	end
end}
for i,v in pairs(sounds) do
	Sound[i] = v
end
return Sound