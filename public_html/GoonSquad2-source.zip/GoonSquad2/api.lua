local Client = require"network/client"
local Particles = require"render/particles"
local requestQueue,queueRequest = Client.requestQueue,Client.queueRequest
function selectWorld(i)
	world = i and worlds[i] or worlds[random(#worlds)]
	worldState = {drops={}}
	if world.drops then
		for i = 1, #world.drops do
			worldState.drops[i] = 0
		end
	end
end
function startGame(mode)
	onlineMode = mode or 0 -- 0 = LAN, 1 = Server, 2 = Client
	gameTime = 0
	state,inGameMenu = 3,0
	selectWorld()
	resetPlayers()
end
local function getSpawnPoint()
	local spawns = world.spawns
	local s = spawns[math.random(1,#spawns)]
	return s[1],s[2]
end
function rotate2D(x,y,r)
	local c,s = math.cos(r),math.sin(r)
	return x*c-y*s,y*c+x*s
end
local playerMetatable = {
__index = {
damage = function(player,damage)
	player.health = player.health-damage
	if player.health < 0 then
		player:reset()
	end
end;
bleed = function(player,angle,number,velocity)
	Particles.Blood(player.x,player.y+1,angle,number,velocity)
end;
press = function(player,inputNumber)
	if inputNumber == 6 then
		if (not player.swordStart and (not player.swordThrow or gameTime-player.swordThrow > swordTimeout)) and
			(not player.punchStart and (not player.punchThrow or gameTime-player.punchThrow > punchTimeout)) and
			(not player.kickStart and (not player.kickThrow or gameTime-player.kickThrow > kickTimeout)) then
			if player.grounded then
				if player.sword then
					player.swordStart = gameTime
					player.swordThrow,player.swordSoundPlayed,player.hitList= nil
				else
					player.punchStart = gameTime
					player.punchThrow,player.punchSoundPlayed,player.hitList= nil
				end
			else
				player.kickStart = gameTime
				player.kickThrow,player.kickSoundPlayed,player.hitList = nil
			end
		end
	elseif inputNumber == 5 then
		player:jump()
	end
end;
bleedTime = function(player,t)
	player.bleeding = t
end;
jump = function(player)
	if player.grounded and gameTime-player.lastLanding > jumpTimeout and not player.punchStart then
		player.grounded = false
		player.yv = jumpVelocity
		player.lastJumpTime = gameTime
		player.jumpTick = true
	end
end;
land = function(player)
	player.grounded = true
	player.lastJumpTime = nil
	player.falling = nil
	player.lastLanding = gameTime
	player.yv = 0
	player.walkingAnim = 0
	player.lastAirFrame = player.rig
end;
updateRig = require"render/anim";
spawn = function(player)
	player.x,player.y = getSpawnPoint()
end;
reset = function(player)
	player.rig = {}
	player.maxHealth = 100
	player.health = player.maxHealth
	player.xv,player.yv = 0,0
	player.walkingAnim = 0
	player.grounded = false
	player.lastJumpTime,player.falling,player.lastAirFrame,player.punchStart,player.punchThrow,player.kickStart,player.kickThrow,player.punchSoundPlayed,player.speedDrop = nil
	player.swordStart,player.swordThrow,player.swordSoundPlayed,player.sword,player.jetpack,player.exhaustPosition = nil
	player.bleeding = nil
	player.hitList = {}
	player.lastLanding = -10
	player.direction = 1
	player.jumpTick = nil
	player:spawn()
end;
}
}
local networkMetatable = {__index={
	isDown = function(t,a)
		return t.down[a]
	end;
	getAxis = function(t,a)
		return t.axises[a] or 0
	end;
	isNetwork=true;
}}
function openSettings(i)
	settingsCursor = 1
	if state == 3 then
		inGameMenu = i
	else
		state = 7
	end
end
function closeSettings()
	inGameMenu = 0
	if state == 7 then
		mainMenu()
	end
end

local function newNetworkJoystick()
	local n = {
	down = {};
	axises = {};
	}
	setmetatable(n,networkMetatable)
	return n
end
local function removePlayers()
	for i,v in pairs(players) do
		removePlayer(i)
	end
end
function resetPlayers()
	Particles.reset()
	for i,v in pairs(players) do
		v:reset()
	end
end
function mainMenu()
	state = 1
	menuCursor = 1
	removePlayers()
	onlineMode = 0
	inGameMenu = 0
end
local function getOpenPlayer()
	for i = 1, maxPlayers do
		if not players[i] then
			return i
		end
	end
end
function removePlayer(i)
	players[i] = nil
	if inGameMenu == i then
		inGameMenu = 0
	end
end
function addPlayer(joystick,isNetwork)
	local playerN
	local newPlayer
	if isNetwork then
		if not joystick then
			joystick = getOpenPlayer()
		end
		if isNetwork == 0 then -- this is the client and it received a confirmation from the server to add the player
			local njoystick
			for i = #requestQueue, 1, -1 do
				if requestQueue[i].message == string.char(1)..string.char(joystick) then
					njoystick = requestQueue[i].data[1]
					table.remove(requestQueue,i)
				end
			end
			if njoystick then
				print("Player added with "..njoystick:getName())
				newPlayer = {joystick=njoystick}
				playerN = joystick
			end
		else -- server added a player from another network
			print("Player added from network")
			newPlayer = {joystick=newNetworkJoystick()}
			playerN = joystick
		end
	else
		if onlineMode == 2 then
			queueRequest(string.char(1)..string.char(getOpenPlayer()),{joystick})
		else
			local pN = getOpenPlayer()
			if pN then
				playerN = pN
				print("Player added with "..joystick:getName())
				newPlayer = {joystick=joystick}
			end
		end
	end
	if playerN and not players[playerN] then
		setmetatable(newPlayer,playerMetatable)
		newPlayer:reset()
		players[playerN] = newPlayer
		return newPlayer
	end
end
function rectCollide(x0,y0,w0,h0,x1,y1,w1,h1)
	return x0 < x1+w1 and x0+w0 > x1 and y0 < y1+h1 and y0+h0 > y1
end