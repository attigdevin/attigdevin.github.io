-- 0 = Lightning
-- 1 == Blood
local bloodResist = 0.3
local bloodGrav = -15

local fire = gfx.newImage("render/particles/fire.png")
local fireSystem = gfx.newParticleSystem(fire,600)
fireSystem:setParticleLifetime(1,1.5)
fireSystem:setSpeed(8)
fireSystem:setDirection(-math.pi/2)
fireSystem:setRotation(0,math.pi*2)
fireSystem:setSpread(0.4)
fireSystem:setSizes(1/128*0.2,1/128*0.6)
fireSystem:setSizeVariation(1)
local a = 255*0.4
fireSystem:setColors(a,a,a,0,0,0,0,0)
local firePerSecond = 240

local emissionBuildup = 0

local Particles
Particles = {
reset = function()
	Particles.list = {}
	fireSystem:reset()
end;
list = {};
Fire = function(x,y)
	fireSystem:setPosition(x,y)
	fireSystem:emit(1)
end;
Blood = function(x,y,angle,n,velocity)
	for i = 1, n do
		local a = angle+(math.random()-0.5)
		local v = velocity*2^(math.random()*2-1)
		local r = math.random()-0.5
		local o = {lifetime=1,type=1,x,y,math.cos(a)*v,math.sin(a)*v,radius=0.12*1.5^(r)}
		o.radiusV=((math.random()-0.5)*0.5)
		table.insert(Particles.list,o)
	end
end;
render = function(dt)
	local l = Particles.list
	for i = #l, 1, -1 do
		local o = l[i]
		o.lifetime = o.lifetime-dt
		if o.lifetime < 0 then
			table.remove(l,i)
		else
			if o.type == 0 then
				local a
				if o.lifetime > 0.4 then
					a = 1-(o.lifetime-0.4)/0.1
				else
					a = o.lifetime/0.4
				end
				a = a*255
				gfx.setColor(255,255,255,a)
				for i2 = 1, #o.lines do
					local li = o.lines[i2]
					gfx.setLineWidth(li[5]*0.08)
					gfx.line(li[1],li[2],li[3],li[4])
				end
			elseif o.type == 1 then
				local oVX,oVY = o[3],o[4]
				o[3],o[4] = o[3]*(0.3^dt),o[4]*(0.3^dt)+bloodGrav*dt
				o[1],o[2] = o[1]+(o[3]+oVX)/2*dt,o[2]+(o[4]+oVY)/2*dt
				gfx.setColor(255,0,0,o.lifetime*255)
				o.radius = o.radius+o.radiusV*dt
				gfx.circle("fill",o[1],o[2],o.radius)
			end
		end
	end
	emissionBuildup = emissionBuildup+dt
	while emissionBuildup > 1/firePerSecond do
		emissionBuildup = emissionBuildup-1/firePerSecond
		for i,player in pairs(players) do
			if player.jetpack and player.exhaustPos and player.joystick:isDown(5) then
				Particles.Fire(player.exhaustPos[1],player.exhaustPos[2])
			end
		end
	end
	fireSystem:update(dt)
	if fireSystem:getCount() > 0 then
		gfx.setBlendMode("add","premultiplied")
		gfx.setColor(255,255,255)
		gfx.draw(fireSystem)
		gfx.setBlendMode("alpha")
	end
end;
addLightningParticle = function(sx,sy,ex,ey)
	local branchDecay = 0.7
	local rot = 0.5
	local o = {type=0,lifetime=0.5}
	local lines = {{sx,sy,ex,ey,1}}
	for _ = 1, 5 do
		for i = #lines, 1, -1 do
			local l = lines[i]
			local offset = math.sqrt((l[1]-l[3])^2+(l[2]-l[4])^2)*0.2
			local nx,ny = (l[1]+l[3])/2,(l[2]+l[4])/2
			local off = (math.random()*2-1)*offset
			local px,py = sy-ey,sx-ex
			local d = math.sqrt(px*px+py*py)
			px,py = px/d,py/d
			nx = nx+px*off,ny+py*off
			lines[i] = {l[1],l[2],nx,ny,l[5]}
			table.insert(lines,{nx,ny,l[3],l[4],l[5]})
			if i < 4 and math.random() < 0.8^_ then--math.random() < 0.85^(2^_) and l[5]*0.6-0.2 > 0 then
				local dx,dy = rotate2D(nx-l[1],ny-l[2],(math.random()*2-1)*rot)
				table.insert(lines,{nx,ny,nx+dx*branchDecay,ny+dy*branchDecay,l[5]-0.2})
			end
		end
	end
	o.lines = lines
	table.insert(Particles.list,o)
end;
}
return Particles