local h = 0.05
local armRadius = 0.07
local aS = armRadius/2
local legRadius = 0.08
local lS = legRadius/2
local neckRadius = 0.08
local neckLength = 0.05
local torsoRadius = 0.1
local armOffset = 0.275-neckLength+0.1-armRadius
local tS = 0.02

local swordMesh = require"render/meshes/sword"
local jetpackMesh = require"render/meshes/jetpack"
local Particles = require"render/particles"

local playerMesh = gfx.newMesh({{"VertexPosition","float",2},{"BoneIndex","float",1},{"VertexColor","byte",4}},
{
{-legRadius,-0.45,0},{legRadius,-0.45,0};	-- 1,2 top left knee
{-legRadius,0,0},{legRadius,0,0};		-- 3,4 top left leg
{-legRadius,0,1},{legRadius,0,1};		-- 5,6 low left knee
{-legRadius,-0.4+lS,1},{legRadius,-0.4+lS,1};	-- 7,8 left foot
{-legRadius+lS,-0.4,1},{legRadius-lS,-0.4,1};	-- 9,10 left foot
{0,0,1};					-- 11 left knee

{-legRadius,-0.45,5},{legRadius,-0.45,5};	-- 1,2 top right knee
{-legRadius,0,5},{legRadius,0,5};		-- 3,4 top right leg
{-legRadius,0,6},{legRadius,0,6};		-- 5,6 low right knee
{-legRadius,-0.4+lS,6},{legRadius,-0.4+lS,6};	-- 7,8 right foot
{-legRadius+lS,-0.4,6},{legRadius-lS,-0.4,6};	-- 9,10 right foot
{0,0,6};					-- 11 right knee

{-torsoRadius,tS,2},{torsoRadius,tS,2};			-- 1,2 low low torso
{-torsoRadius,0.375,2},{torsoRadius,0.375,2};	-- 3,4 high low torso
{-torsoRadius+tS,0,2},{torsoRadius-tS,0,2}; -- 5,6 low low torso curve
{0,0,2};	-- 7 low low mid torso
{-torsoRadius,0,3},{torsoRadius,0,3};	-- 1,2 low high torso
{-torsoRadius,0.375-neckLength-tS,3},{torsoRadius,0.375-neckLength-tS,3};		-- 3,4 high high torso

{-neckRadius,0.375-neckLength,3},{neckRadius,0.375-neckLength,3};		-- 5,6 low neck
{-neckRadius,0,4},{neckRadius,0,4};		-- 7,8 high neck neck
{-torsoRadius+tS,0.375-neckLength,3},{torsoRadius-tS,0.375-neckLength,3}; -- 9,10 high high torso curve

{-0.2+h,0,4},{0.2-h,0,4}; -- 1,2 head
{-0.2+h,0.4,4},{0.2-h,0.4,4}; -- 3,4
{-0.2,0+h,4},{0.2,0+h,4}; -- 5,6
{-0.2,0.4-h,4},{0.2,0.4-h,4}; -- 7,8

{-armRadius,-0.4,7},{armRadius,-0.4,7};	-- 1,2 left arm
{-armRadius,0,7},{armRadius,0,7};		-- 3,4
{-armRadius,0,8},{armRadius,0,8};		-- 5,6
{-armRadius,-0.35+aS,8},{armRadius,-0.35+aS,8};	-- 7,8
{-armRadius+aS,-0.35,8},{armRadius-aS,-0.35,8};	-- 9,10
{0,0,8};					-- 11

{-armRadius,-0.4,9},{armRadius,-0.4,9};	-- 1,2 right arm
{-armRadius,0,9},{armRadius,0,9};		-- 3,4
{-armRadius,0,10},{armRadius,0,10};		-- 5,6
{-armRadius,-0.35+aS,10.1},{armRadius,-0.35+aS,10.1};	-- 7,8
{-armRadius+aS,-0.35,10.1},{armRadius-aS,-0.35,10.1};	-- 9,10
{0,0,10};					-- 11

{0.05,0.1,4,0,0,0},{0.2,0.1,4,0,0,0}; -- 1,2 mouth
{0.05,0.15,4,0,0,0},{0.2,0.15,4,0,0,0}; -- 3,4
{0.08,0.23,4,0,0,0},{0.13,0.23,4,0,0,0}; -- 5,6 eye
{0.08,0.28,4,0,0,0},{0.13,0.28,4,0,0,0}; -- 7,8

},"triangles","static")

local vertexMapPre = {
1,2,3,3,4,2; -- left thigh
5,6,7,7,8,6; -- left calf
7,9,10,8,7,10; --
6,2,11;		 -- left knee
"11";--21
1,2,3,3,4,2; -- right thigh
5,6,7,7,8,6; -- right calf
7,9,10,8,7,10; --
6,2,11;		 -- right knee
"11";--42
1,2,3,3,4,2; -- low torso
7,4-22,6;7,3-22,5; -- triangle cuts
7,4-11,6;7,3-11,5; -- triangle cuts
5,6,2;1,5,2;
"7";--66
1,2,3,3,4,2; -- upper torso
5,6,7,7,8,6; -- neck
9,10,4;3,9,4;
"10";--84
1,2,3,3,4,2; -- head
1,3,5,3,5,7;
"1";--96
1,3,5,3,5,7;
"7";--102
1,2,3,3,4,2; -- left arm
5,6,7,7,8,6; --
7,9,10,8,7,10; --
5,1,11;		 --
"11";--123
1,2,3,3,4,2; -- right arm
5,6,7,7,8,6; --
7,9,10,8,7,10; --
5,1,11;		 --
"11";--144
1,2,3;2,3,4;
5,6,7;6,7,8;
--156
}
local vertexMap = {}
local j = 0
local add = 0
for i = 1, #vertexMapPre do
	local a = vertexMapPre[i]
	if type(a) == "string" then
		add = add+tonumber(a)
		--print(j)
	else
		table.insert(vertexMap,a+add)
		j = j+1
	end
end

playerMesh:setVertexMap(vertexMap)

local playerShader = gfx.newShader([[
vec4 effect(vec4 color, Image texture, vec2 texture_coords, vec2 screen_coords)
{
	return color;
}
]],[[
attribute float BoneIndex;

extern float ext;
extern mat4 bones[12];

vec4 position(mat4 transform_projection, vec4 vertex_position)
{
	if (BoneIndex == 10.1){
		vertex_position += vec4(0.0,-ext,0.0,0.0);
	}
    return transform_projection * bones[int(BoneIndex)] * vertex_position;
}
]])

local function newMatrix(rot,x,y)
	return {{math.cos(rot),math.sin(rot),0,0};{-math.sin(rot),math.cos(rot),0,0};{0,0,0,0};{x,y,0,1};}
end
local function newMatrixFromPast(rot,x,y,m)
	return {{math.cos(rot),math.sin(rot),0,0};{-math.sin(rot),math.cos(rot),0,0};{0,0,0,0};{m[4][1]+x*m[1][1]+y*m[2][1],m[4][2]+x*m[1][2]+y*m[2][2],0,1};}
end

local function computeMatrices(rigInfo)
	local matrices = {}
	local leftHip = rigInfo.leftHip or 0
	local leftKnee = rigInfo.leftKnee or 0
	local leftShoulder = rigInfo.leftShoulder or 0
	local leftElbow = rigInfo.leftElbow or 0
	local rightHip = rigInfo.rightHip or 0
	local rightKnee = rigInfo.rightKnee or 0
	local rightShoulder = rigInfo.rightShoulder or 0
	local rightElbow = rigInfo.rightElbow or 0
	local pelvis = rigInfo.pelvis or 0
	local back = rigInfo.back or 0
	local neck = rigInfo.neck or 0
	matrices[1] = newMatrix(leftHip,0,0.85)
	matrices[2] = newMatrixFromPast(leftKnee+leftHip,0,-0.45,matrices[1])
	
	matrices[3] = newMatrix(pelvis,0,0.85)
	matrices[4] = newMatrixFromPast(pelvis+back,0,0.375,matrices[3])
	matrices[5] = newMatrixFromPast(pelvis+back+neck,0,0.375-0,matrices[4])
	
	matrices[6] = newMatrix(rightHip,0,0.85)
	matrices[7] = newMatrixFromPast(rightKnee+rightHip,0,-0.45,matrices[6])
	
	matrices[8] = newMatrixFromPast(leftShoulder+back+pelvis,0,armOffset,matrices[4])
	matrices[9] = newMatrixFromPast(leftElbow+leftShoulder+back+pelvis,0,-0.4,matrices[8])
	
	matrices[10] = newMatrixFromPast(rightShoulder+back+pelvis,0,armOffset,matrices[4])
	matrices[11] = newMatrixFromPast(rightElbow+rightShoulder+back+pelvis,0,-0.4,matrices[10])
	
	local m = matrices[2]
	local footBottom1 = 0.4*m[2][2]-m[4][2]
	m = matrices[7]
	local footBottom2 = 0.4*m[2][2]-m[4][2]
	return matrices,math.max(footBottom1,footBottom2)
end

local playerDraw = {}

playerDraw.rightArm = function(color)
	gfx.setColor(color)
	playerMesh:setDrawRange(124,144)
	gfx.draw(playerMesh)
end
playerDraw.leftArm = function(color)
	gfx.setColor(color)
	playerMesh:setDrawRange(103,123)
	gfx.draw(playerMesh)
end
playerDraw.face = function(color)
	playerMesh:setDrawRange(145,156)
	gfx.draw(playerMesh)
end
playerDraw.nonRightArm = function(color)
	gfx.setColor(color)
	playerMesh:setDrawRange(1,123)
	gfx.draw(playerMesh)
end
playerDraw.nonArms = function(color)
	gfx.setColor(color)
	playerMesh:setDrawRange(1,102)
	gfx.draw(playerMesh)
end
local function flipTable(t)
	local n = #t
	for i = 1, #t do
		print(t[i])
	end
	for i = 1, math.floor(n/2) do
		t[i],t[n-i] = t[n-i],t[i]
	end
	for i = 1, #t do
		print(t[i])
	end
end

local function renderPlayer(player,playerNumber)
	local x,y,color,rigInfo,dir = player.x,player.y,colors.playerColors[playerNumber],player.rig,player.direction
	local matrices,offset = computeMatrices(rigInfo)
	playerShader:send("bones",matrices[1],matrices[2],matrices[3],matrices[4],matrices[5],matrices[6],matrices[7],matrices[8],matrices[9],matrices[10],matrices[11],matrices[11])
	playerShader:send("ext",rigInfo.rightExtend or 0)
	
	gfx.push()
	gfx.translate(x,y+offset)
	if dir == -1 then
		gfx.scale(-1,1)
	end
	
	gfx.setShader(playerShader)
	
	local order = dir == 1 and {"nonRightArm","face","jetpack","sword","rightArm"} or {"rightArm","sword","nonArms","face","jetpack","leftArm"}
	
	for i = 1, #order do
		local o = order[i]
		if o == "sword" then
			if player.sword then
				gfx.push()
				gfx.setShader()
				local elbow = matrices[11]
				gfx.translate(elbow[4][1],elbow[4][2])
				gfx.rotate((rigInfo.rightElbow or 0)+(rigInfo.rightShoulder or 0)+(rigInfo.back or 0)+(rigInfo.pelvis or 0)-math.pi/2)
				gfx.translate(0.3,0.15)
				gfx.setColor(255,255,255)
				gfx.draw(swordMesh)
				gfx.setShader(playerShader)
				gfx.pop()
			end
		elseif o == "jetpack" then
			if player.jetpack then
				gfx.push()
				gfx.setShader()
				local back = matrices[4]
				gfx.translate(back[4][1],back[4][2])
				local rot = (rigInfo.back or 0)+(rigInfo.pelvis or 0)
				gfx.rotate(rot)
				gfx.setColor(255,255,255)
				gfx.translate(-0.1,-0.0375)
				gfx.draw(jetpackMesh)
				gfx.pop()
				
				local cx,cy = -0.1,-0.3
				local rx,ry = math.cos(rot),math.sin(rot)
				
				player.exhaustPos = {x+back[4][1]+(cx*rx-cy*ry)*dir,y+back[4][2]+(cy*rx+cx*ry)}
				
				gfx.setShader(playerShader)
			end
		else
			playerDraw[o](color)
		end
	end
	
	gfx.setShader()
	
	gfx.pop()
end

return renderPlayer