local menuFont = fonts.p32
local menuFontHeight = menuFont:getHeight()
local menuFontHighlight = fonts.p48
local menuFontHighlightHeight = menuFontHighlight:getHeight()
local Server,Client = require"network/server",require"network/client"
menuOptions = {{"Local Play",startGame},{"Host Server",Server.startServer},{"Join Server",Client.joinServer},{"Settings",openSettings}}
local menuBoxSize = 400

return function()
	gfx.clear(colors.menuBackground)
	local y = 100
	for i = 1, #menuOptions do
		local o = menuOptions[i]
		local selected = menuCursor == i
		local font = selected and menuFontHighlight or menuFont
		local fontSize = selected and menuFontHighlightHeight or menuFontHeight
		local boxSize = menuBoxSize+(selected and 100 or 0)
		gfx.setColor(30,30,30,128)
		gfx.rectangle("fill",w/2-menuBoxSize,y-10,boxSize+10,fontSize+20)
		gfx.setFont(font)
		gfx.setColor(colors.white)
		gfx.printf(o[1],w/2-menuBoxSize,y,boxSize,"right")
		y = y+fontSize+40
	end
	gfx.setFont(fonts.p18)
	gfx.printf("Controls:\nWASD - Move\nE - Pause\nShift - Attack/Select\nSpace - Jump",0,h-120,w,"center")
end