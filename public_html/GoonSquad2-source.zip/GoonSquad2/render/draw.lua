local titleFont = fonts.p144
local titleHeight = titleFont:getHeight()
local titleSmallFont = fonts.p24
local titleSmallFontHeight = titleSmallFont:getHeight()
local connectingFont = fonts.p48
local connectingFontHeight = connectingFont:getHeight()

local cx,cy = 0,1
local unitsPerWidth = 24
local widthBuffer = 16
local camSpeed = 0.01
local growSpeed = 0.0025
local minWidth = 20

local renderPlayer = require"render/player"
local renderWorld = require"render/world"
local renderMenu = require"render/menu"
local renderSettings = require"render/settings"
local Drops = require"drops"
local Particles = require"render/particles"
local Attack = require"attack"

local getRig = require"render/anim"

local loadCircleShader = gfx.newShader[[
extern vec2 c;
extern float r;
vec4 effect(vec4 color, Image texture, vec2 texture_coords, vec2 screen_coords)
{
	float d = distance(screen_coords,c);
	float a = 2.0-(d/r)*2.0;
    return vec4(1.0,1.0,1.0,a);
}
]]

local function updateCamera(dt)
	local gx,gy = 0,0
	local np = 0
	local left,right,bottom,top
	for i,v in pairs(players) do
		if not v.joystick.isNetwork or true then
			if not right or v.x > right then
				right = v.x
			end
			if not left or v.x < left then
				left = v.x
			end
			if not top or v.y > top then
				top = v.y
			end
			if not bottom or v.y < bottom then
				bottom = v.y
			end
			np = np+1
		end
	end
	if np > 0 then
		local d = right-left
		local dh = (top-bottom)*aspectRatio
		if dh > d then
			d = dh
		end
		local gScale = d+widthBuffer
		if gScale < minWidth then
			gScale = minWidth
		end
		local a = 1-camSpeed^dt
		local a2 = 1-growSpeed^dt
		unitsPerWidth = unitsPerWidth+(gScale-unitsPerWidth)*a2
		cx,cy = cx+((left+right)/2-cx)*a,cy+((top+bottom+2)/2-cy)*a
	end
end
local function drawLoadCircle(x,y,r)
	loadCircleShader:send("c",{x,y})
	loadCircleShader:send("r",r)
	gfx.circle("fill",x,y,r)
end

return function(dt)
	if state == 0 then
		gfx.clear(colors.black)
		gfx.setFont(titleFont)
		gfx.setColor(colors.white)
		gfx.printf("Goon Squad",0,h/2-titleHeight/2,w,"center")
		gfx.setFont(titleSmallFont)
		gfx.setColor(255,255,255,(math.cos(startDelta*1.2)+1)*127.5)
		gfx.printf("Press any button or key to continue . . .",0,h/2+titleHeight/2+titleSmallFontHeight/2,w,"center")
	elseif state == 1 then
		renderMenu()
	elseif state == 3 then
		gfx.clear(world.backgroundColor or colors.defaultBackgroundColor)
		gfx.translate(w/2,h/2)
		updateCamera(dt)
		local unitsPerWidth = love.keyboard.isDown("4") and unitsPerWidth*0.2 or unitsPerWidth
		gfx.scale(w/unitsPerWidth,-w/unitsPerWidth)
		local unitsPerHeight = unitsPerWidth/aspectRatio
		gfx.translate(-cx,-cy)
		if d25 then
			renderWorld() -- 2.5D
			gfx.translate(0,0.1)
		end
		for playerNumber,player in pairs(players) do
			player:updateRig()
			renderPlayer(player,playerNumber)
			if debugMode then
				gfx.setColor(colors.debugColor1)
				Attack.drawPunchBox(player)
				Attack.drawKickBox(player)
				Attack.drawSwordBox(player)
				gfx.setLineWidth(0.05)
				gfx.rectangle("line",player.x-0.5,player.y,1,2)
			end
		end
		if not d25 then
			renderWorld() -- 2.5D
		end
		Drops.renderDrops(cx,cy,unitsPerWidth,unitsPerHeight)
		Particles.render(dt)
		for i,player in pairs(players) do
			if true then
				gfx.setColor(0,255,0)
				gfx.rectangle("fill",player.x-0.5,player.y+2.1,player.health/100,0.2)
				gfx.setColor(255,0,0)
				gfx.rectangle("fill",player.x-0.5+player.health/100,player.y+2.1,1-player.health/100,0.2)
			end
		end
		gfx.origin()
	elseif state == 4 or state == 5 or state == 6 then -- connecting to server
		gfx.clear(colors.black)
		gfx.setColor(colors.white)
		gfx.setShader(loadCircleShader)
		gfx.push()
		local n = 8
		local bigR,lilR = 20,5
		local partPi = math.pi*2/n
		local rot = startDelta
		for i = 1, n do
			local cr = partPi*i+rot
			drawLoadCircle(w/2+math.cos(cr)*bigR,h/2+math.sin(cr)*bigR,lilR+math.sin(cr+startDelta)*2)
		end
		gfx.pop()
		gfx.setShader()
		if state == 5 or state == 6 then -- hole punching
			gfx.setColor(colors.white)
			gfx.setFont(fonts.p18)
			gfx.print("Setting up hole punching...",0,20)
		end
	elseif state == 7 then
		renderSettings()
	end
	if inGameMenu ~= 0 then
		renderSettings()
		if state == 7 then
			print("You fricking suck")
		end
	end
	if showFPS == true then
		gfx.setColor(colors.white)
		gfx.setFont(fonts.p14)
		gfx.print("FPS: "..love.timer.getFPS(),0,0)
	end
	gfx.present()
end