return function()
	local r = world.render
	for i = 1, #r do
		local o = r[i]
		gfx.setColor(o[1])
		if o[2] == 0 then -- rectangle
			gfx.rectangle("fill",o[3],o[4],o[5],o[6])
		end
	end
end