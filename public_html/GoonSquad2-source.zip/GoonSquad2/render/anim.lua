local jumpAnimTransition,fallAnimTransition,landAnimTransition = 0.125,0.5,0.25
local fallAnimSpeed = 4
local fallThreshold = -5
local swordPickup = 0.5

--endFrames are the times when that frame is no longer relevant (meaning the next 2 frames have taken over)

local frameComponents = {"leftHip","leftKnee","leftShoulder","leftElbow","pelvis","back","neck","rightHip","rightKnee","rightShoulder","rightElbow","rightExtend"}
local function lerpFrames(a,b,alpha)
	local o = {}
	local beta = 1-alpha
	for i = 1, #frameComponents do
		local c = frameComponents[i]
		if c == "rightExtend" then
			local ac,bc = a[c],b[c]
			if ac then
				if bc then
					o[c] = ac*beta+bc*alpha
				else
					o[c] = ac*beta
				end
			else
				o[c] = bc and bc*alpha or 0
			end
		else
			local ac,bc = a[c],b[c]
			if ac then
				if bc then
					o[c] = ac*beta+bc*alpha
				else
					o[c] = ac
				end
			else
				o[c] = bc
			end
		end
	end
	return o
end
local zeroFrame = {}
local animations = {
walk = require"render/animations/walk";
jumpFrame = require"render/animations/jump";
fall = require"render/animations/fall";
landFrame = require"render/animations/land";
punchFrame1 = require"render/animations/punchHold";
punchFrame2 = require"render/animations/punchFire";
swordFrame1 = require"render/animations/swordHold";
swordFrame2 = require"render/animations/swordFire";
kickFrame1 = require"render/animations/kickHold";
kickFrame2 = require"render/animations/kickFire";
swordWalk = require"render/animations/swordWalk";
}

local function fromAnimation(anim,alpha)
	alpha = alpha%1
	local frames = anim.frames
	local endTimes = anim.endTimes
	local lastEndTime = 0
	for i = 1, #frames do
		local frame = frames[i]
		local endTime = endTimes[i]
		if lastEndTime <= alpha and endTime > alpha then
			return lerpFrames(frame,frames[i%#frames+1],(alpha-lastEndTime)/(endTime-lastEndTime))
		end
		lastEndTime = endTime
	end
end

local function getGroundFrame(player)
	local landDt = gameTime-player.lastLanding
	if landDt < jumpTimeout then -- just landed, don't give a shit about walking animation
		return lerpFrames(player.lastAirFrame,animations.landFrame,(landDt)/jumpTimeout)
	else
		local walkFrame = fromAnimation(animations.walk,player.walkingAnim)
		if player.sword then
			local dt = (gameTime-player.sword)/swordPickup
			local d = walkFrame.rightShoulder
			walkFrame = lerpFrames(walkFrame,fromAnimation(animations.swordWalk,player.walkingAnim),dt > 1 and 1 or dt)
		end
		if landDt-jumpTimeout < landAnimTransition then
			return lerpFrames(animations.landFrame,walkFrame,(landDt-jumpTimeout)/landAnimTransition)
		else
			return walkFrame
		end
	end
end

return function(player)
	if player.grounded then
		player.rig = getGroundFrame(player)
	else
		if player.lastJumpTime then
			local jumpDt = gameTime-player.lastJumpTime
			if jumpDt < jumpAnimTransition then
				player.rig = lerpFrames(getGroundFrame(player),animations.jumpFrame,jumpDt/jumpAnimTransition)
			else
				player.rig = animations.jumpFrame
			end
		else
			player.rig = getGroundFrame(player)
		end
		if player.yv < fallThreshold then
			if not player.falling then
				player.falling = gameTime
			end
			local dt = gameTime-player.falling
			local fallFrame = fromAnimation(animations.fall,dt*fallAnimSpeed)
			if dt < fallAnimTransition then
				local laps = -math.floor(dt*fallAnimSpeed)*pi2 -- WARNING CUSTOM SHIT RIGHT HERE
				fallFrame.rightShoulder,fallFrame.leftShoulder = fallFrame.rightShoulder+laps,fallFrame.leftShoulder+laps
				player.rig = lerpFrames(player.rig,fallFrame,dt/fallAnimTransition,true)
				player.rig.rightShoulder,player.rig.leftShoulder = (player.rig.rightShoulder+pi)%pi2-pi,(player.rig.leftShoulder+pi)%pi2-pi
			else
				player.rig = fallFrame
			end
		end
	end
	if player.swordThrow then
		local dt = gameTime-player.swordThrow
		if dt < swordTimeout then
			player.rig = lerpFrames(animations.swordFrame2,player.rig,dt/swordTimeout)
		end
	elseif player.swordStart then
		local alpha = (gameTime-player.swordStart)/swordDelay
		if alpha < swordPercentStart then
			player.rig = lerpFrames(player.rig,animations.swordFrame1,alpha/swordPercentStart)
		else
			player.rig = lerpFrames(lerpFrames(player.rig,animations.swordFrame1,1),animations.swordFrame2,(alpha-swordPercentStart)/(1-swordPercentStart))
		end
	end
	if player.punchThrow then
		local dt = gameTime-player.punchThrow
		if dt < punchTimeout then
			player.rig = lerpFrames(animations.punchFrame2,player.rig,dt/punchTimeout)
		end
	elseif player.punchStart then
		local alpha = (gameTime-player.punchStart)/punchDelay
		if alpha < punchPercentStart then
			player.rig = lerpFrames(player.rig,animations.punchFrame1,alpha/punchPercentStart)
		else
			player.rig = lerpFrames(lerpFrames(player.rig,animations.punchFrame1,1),animations.punchFrame2,(alpha-punchPercentStart)/(1-punchPercentStart))
		end
	end
	if player.kickThrow then
		local dt = gameTime-player.kickThrow
		if dt < kickTimeout then
			player.rig = lerpFrames(animations.kickFrame2,player.rig,dt/kickTimeout)
		end
	elseif player.kickStart then
		local alpha = (gameTime-player.kickStart)/kickDelay
		if alpha < kickPercentStart then
			player.rig = lerpFrames(player.rig,animations.kickFrame1,alpha/kickPercentStart)
		else
			player.rig = lerpFrames(lerpFrames(player.rig,animations.kickFrame1,1),animations.kickFrame2,(alpha-kickPercentStart)/(1-kickPercentStart))
		end
	end
end