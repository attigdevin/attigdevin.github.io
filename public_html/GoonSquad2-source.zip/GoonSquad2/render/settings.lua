-- Variable types:
-- 0: bool
-- 1: enum

local settingsFont = fonts.p32
local settingsFontHeight = settingsFont:getHeight()
local margin = 50
local boxWidth = 300
local Network = require"network/network"

local saveWW,saveWH,saveWX,saveWY = 1280,720,80,90

settingsOptions = {{"V-Sync",activated=function(value)
	local cw,ch,cf = love.window.getMode()
	if cf.vsync ~= value then
		cf.vsync = value
		love.window.setMode(cw,ch,cf)
	end
end,type=0,default=false},{"Fullscreen",activated=function(value)
	local cw,ch,cf = love.window.getMode()
	if cf.fullscreen ~= value then
		if value == true then
			saveWW,saveWH,saveWX,saveWY = cw,ch,cf.x,cf.y
			cw,ch = love.window.getDesktopDimensions()
		else
			cw,ch = saveWW,saveWH
			cf.x,cf.y = saveWX,saveWY
		end
		cf.fullscreen = value
		love.window.setMode(cw,ch,cf)
		w,h = cw,ch
	end
end,type=0,default=false},{"2.5D",activated=function(value)
	d25 = value
end,type=0,defualt=false},{"MSAA",activated=function(value)
	local cw,ch,cf = love.window.getMode()
	if cf.msaa ~= value then
		cf.msaa = value
		love.window.setMode(cw,ch,cf)
	end
end,type=1,values={0,1,2,8},default=1},
{"Local Hole Punch",activated=function(value)
Network.holePunchIP=value and Network.localPunchIP or Network.globalPunchIP
print("Hole Punch Server: "..Network.holePunchIP)
end,default=true,type=0},{"Main Menu",activated=mainMenu}}

local function updateSetting(i) -- just refresh it, no value change
	local o = settingsOptions[i]
	if o.activated then
		if o.type == 1 then
			o.activated(o.values[o.value])
		else
			o.activated(o.value)
		end
	end
end
local function activateSetting(i,a) -- value change and then refresh
	local o = settingsOptions[i]
	if o.type == 0 then
		o.value = not o.value
	elseif o.type == 1 then
		o.value = (o.value+1*(a or 1)-1)%(#o.values)+1
	end
	updateSetting(i)
end

for i = 1, #settingsOptions do
	local o = settingsOptions[i]
	o.value = o.default
	updateSetting(i)
end

function settingsActivated(a)
	activateSetting(settingsCursor,a)
end

return function()
	if inGameMenu == 0 then
		gfx.clear(colors.settingsMenu)
	end
	local y = 50
	for i = 1, #settingsOptions do
		local o = settingsOptions[i]
		if i == settingsCursor then
			gfx.setColor(255,255,255,128)
		else
			gfx.setColor(30,30,30,128)
		end
		gfx.rectangle("fill",margin,y,boxWidth,settingsFontHeight+20)
		if o.type then
			gfx.rectangle("fill",margin+boxWidth+20,y,boxWidth,settingsFontHeight+20)
		end
		gfx.setFont(settingsFont)
		gfx.setColor(colors.white)
		gfx.printf(o[1],margin+10,y+10,boxWidth,"left")
		if o.type == 0 then
			gfx.printf(o.value and "Enabled" or "Disabled",margin+10+boxWidth+20,y+10,boxWidth,"left")
		elseif o.type == 1 then
			gfx.printf(o.values[o.value],margin+10+boxWidth+20,y+10,boxWidth,"left")
		elseif o.type then
			gfx.printf(tostring(o.value),margin+10+boxWidth+20,y+10,boxWidth,"left")
		end
		y = y+settingsFontHeight+40
	end
end