return {endTimes = {0.5,1,1};

frames={{rightShoulder=1.9198621771938;leftHip=0.69813170079773;leftElbow=2.0943951023932;leftKnee=0;leftShoulder=-1.221730476396;pelvis=0;rightKnee=0;neck=0;back=0;rightElbow=0;rightHip=-0.69813170079773;};
{rightShoulder=-1.221730476396;leftHip=-0.69813170079773;leftElbow=0;leftKnee=0;leftShoulder=-4.3633231299858;pelvis=0;rightKnee=0;neck=0;back=0;rightElbow=2.0943951023932;rightHip=0.69813170079773;};
{rightShoulder=-4.3633231299858;leftHip=0.69813170079773;leftElbow=2.0943951023932;leftKnee=0;leftShoulder=-7.5049157835756;pelvis=0;rightKnee=0;neck=0;back=0;rightElbow=0;rightHip=-0.69813170079773;};
};
}