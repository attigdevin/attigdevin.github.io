return {
frames={
{rightShoulder=0.69813170079773;leftElbow=1.221730476396;leftShoulder=0.61086523819802;rightElbow=1.3962634015955;};
{rightShoulder=0.34906585039887;leftElbow=0.5235987755983;leftShoulder=0.17453292519943;rightElbow=0.69813170079773;};
};
endTimes = {0.5,1};
};