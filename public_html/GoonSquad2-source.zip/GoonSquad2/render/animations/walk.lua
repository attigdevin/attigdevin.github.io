return {
frames={
{leftHip=0,leftKnee=0,rightHip=0,rightKnee=0,leftShoulder=0,rightShoulder=0,leftElbow=0,rightElbow=0};
{leftHip=-0.2,leftKnee=-0.5,rightHip=1,rightKnee=-1,leftShoulder=0.5,rightShoulder=-0.5,leftElbow=0,rightElbow=0};
{leftHip=-0.2,leftKnee=-1,rightHip=1,rightKnee=-1,leftShoulder=1,rightShoulder=-1,leftElbow=0,rightElbow=0};
{leftHip=0,leftKnee=0,rightHip=0,rightKnee=0,leftShoulder=0,rightShoulder=0,leftElbow=0,rightElbow=0};
{rightHip=-0.2,rightKnee=-0.5,leftHip=1,leftKnee=-1,leftShoulder=-0.5,rightShoulder=0.5,leftElbow=0,rightElbow=0};
{rightHip=-0.2,rightKnee=-1,leftHip=1,leftKnee=-1,leftShoulder=-1,rightShoulder=1,leftElbow=0,rightElbow=0}};
endTimes = {0.125,0.25,0.5,0.625,0.75,1};
};