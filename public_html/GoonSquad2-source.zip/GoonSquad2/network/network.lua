--[[
Client send packet info, all numbers are packed in bytes:
	Add to list of receivers:
	0
	Request a player connect:
	1
	Request update to player position:
	2	Player#	10length	10 bytes of data

Server send packet info:
	Regular data update:
	0	N	PlayerNDataLength	PlayerNData
		PlayerNData:
		0/1 Owned	If not owned, 10 bytes
Hole punch info:
	Starts with byte 255
		Hole puncher recieve:
			7: Request to start process. If its the first one, then that is marked as the server, sends 1 message to both server and client
			8: Receives IP to stop sending reminders to
		Client recieve:
			1: Recieves server IP and own IP. Sends own IP to server as a 2 message
			2: Receives own IP and sends it to hole punch server to tell it to stop
			4: Done with everything, start regular mode
		Server receive:
			0: Start server
			1: Recieves a client IP and own IP. Sends own IP to client as a 2 message
			2: Receives own IP and sends it to hole punch server to tell it to stop
		
]]
local Network = {}
local socket = require"socket"
local positionResolution = 100
local udp = socket.udp()
udp:settimeout(0)
Network.udp = udp
Network.globalPunchIP,Network.localPunchIP = "0.0.0.0","127.0.0.1"
Network.holePunchIP = Network.globalPunchIP
Network.holePunchPort = 5006

Network.getIPFromBytes = function(ipBytes)
	local IP = tostring(ipBytes:byte(1)).."."..tostring(ipBytes:byte(2)).."."..tostring(ipBytes:byte(3)).."."..tostring(ipBytes:byte(4))
	local Port = ipBytes:byte(5)*256+ipBytes:byte(6)
	return IP,Port
end
Network.IPtoBytes = function(ip,port)
	local out = ""
	local a,b,c,d = ip:match("(%d+)%.(%d+)%.(%d+)%.(%d+)")
	out = out..string.char(tonumber(a))..string.char(tonumber(b))..string.char(tonumber(c))	..string.char(tonumber(d))..string.char(math.floor(port/256))..string.char(port%256)
	return out
end
local function intToByteString(n) -- between 32767
	local neg = n < 0
	n = math.abs(n)
	if n > 32767 then error(n.." too big to convert to 2 bytes")end
	local b1 = math.floor(n/256)
	return string.char(neg and b1+128 or b1)..string.char(n%256)
end
local function byteStringToInt(n) -- only works with 2 bytes
	local firstByte = n:byte(1)
	local m = 1
	if firstByte > 127 then
		firstByte = firstByte-128
		m = -1
	end
	return m*(firstByte*256+n:byte(2))
end
Network.getBytes = function(s)
	local o = {}
	for i in s:gmatch(".") do
		table.insert(o,i:byte())
	end
	return table.concat(o," ")
end
Network.packPlayer = function(player)
	local joystick = player.joystick
	local x = intToByteString(math.floor(player.x*positionResolution+0.5))
	local y = intToByteString(math.floor(player.y*positionResolution+0.5))
	local xv = intToByteString(math.floor(player.xv*positionResolution+0.5))
	local yv = intToByteString(math.floor(player.yv*positionResolution+0.5))
	local axis = string.char(math.floor((joystick:getAxis(1)+1)*127.5))..string.char(math.floor((joystick:getAxis(2)+1)*127.5))..string.char(math.floor(player.health/player.maxHealth*255+0.5))
	local add = ""
	local space,punchIncluded,kickIncluded,swordIncluded,jumpTimeIncluded = 0,0,0,0,0
	if player.joystick:isDown(5) then
		space = 1
	end
	if player.punchStart then
		local dt = (gameTime-player.punchStart)/punchDelay
		if dt < 1 then
			punchIncluded = 1
			add = add..string.char(math.floor(dt*256))
		end
	end
	if player.kickStart then
		local dt = (gameTime-player.kickStart)/kickDelay
		if dt < 1 then
			kickIncluded = 1
			add = add..string.char(math.floor(dt*256))
		end
	end
	if player.swordStart then
		local dt = (gameTime-player.swordStart)/swordDelay
		if dt < 1 then
			swordIncluded = 1
			add = add..string.char(math.floor(dt*256))
		end
	end
	if player.lastJumpTime then
		local dt = gameTime-player.lastJumpTime
		if dt < 1 then
			jumpTimeIncluded = 1
			add = add..string.char(math.floor(dt*256))
		end
	end
	local n = space+punchIncluded*2+kickIncluded*4+swordIncluded*8+jumpTimeIncluded*16
	if n > 0 or true then
		add = string.char(n)..add
	end
	return x..y..xv..yv..axis..add
end
--[[
Event data:
	00000001 = time since last jump * 256
	00000010 = time since last punch start * 512
	00000100 = time since last kick start * 512
]]
Network.unpackPlayer = function(player,data)
	player.lastReceived = startDelta
	local l = #data
	player.x = byteStringToInt(data:sub(1,2))/positionResolution
	player.y = byteStringToInt(data:sub(3,4))/positionResolution
	player.xv = byteStringToInt(data:sub(5,6))/positionResolution
	player.yv = byteStringToInt(data:sub(7,8))/positionResolution
	player.joystick.axises = {(data:byte(9)/127.5)-1,(data:byte(10)/127.5)-1}
	player.health = data:byte(11)/255*player.maxHealth
	i = 12
	if i <= l then
		local extras = data:byte(i)
		i = i+1
		if extras%2 == 1 then
			extras = extras-1
			player.joystick.down[5] = true
		else
			player.joystick.down[5] = false
		end
		if extras%4 == 2 then
			extras = extras-2
			local da = data:byte(i)/256
			if da < 0.5 then -- just started a punch
				player.punchThrow,player.hitList = nil
				player.punchStart = gameTime-da*punchDelay
			end
			i = i+1
		else
			player.punchStart = nil
		end
		if extras%8 == 4 then
			extras = extras-4
			local da = data:byte(i)/256
			if da < 0.5 then
				player.kickThrow,player.hitList = nil
				player.kickStart = gameTime-da*kickDelay
			end
			i = i+1
		else
			player.kickStart = nil
		end
		if extras%16 == 8 then
			extras = extras-8
			local da = data:byte(i)/256
			if da < 0.5 then
				player.swordThrow,player.hitList = nil
				player.swordStart = gameTime-da*swordDelay
			end
			i = i+1
		else
			player.swordStart = nil
		end
		if extras%32 == 16 then
			extras = extras-16
			if not player.grounded then
				player.lastJumpTime = gameTime-data:byte(i)/256
			end
			i = i+1
		end
	end
end
return Network