local Network = require"network/network"
local udp,holePunchPort = Network.udp,Network.holePunchPort

local unpackPlayer,getIPFromBytes,getBytes,packPlayer = Network.unpackPlayer,Network.getIPFromBytes,Network.getBytes,Network.packPlayer

local serverUpdateRate = 0
local serverSendRate = 1/60
local serverUpdateTime = 0
local serverSendTime = 0

local receivers = {}

local lastHolePunch = 0
local holePunchTickRate = 0.1

local killClientTimeout = 3
local Server

local function packWorld()
	local drops = worldState.drops
	local o = string.char(#drops)
	for i = 1,#drops do
		o = o..string.char(drops[i])
	end
	return o
end

local function packPlayerFromServer(player)
	local flags = {player.sword,player.jetpack,player.speedDrop}
	local t = 0
	local p2 = 1
	for i = 1, 3 do
		t = t+(flags[i] and p2 or 0)
		p2 = p2*2
	end
	local data = string.char(t)
	if flags[1] then
		local v = (gameTime-player.sword)*255
		data = data..string.char(v > 255 and 255 or v)
	end
	if flags[2] then
		data = data..string.char(player.jetpack/jetpackFuel*255)
	end
	if flags[3] then
		local v = gameTime-player.speedDrop
		data = data..string.char(v/speedDropDuration*255)
	end
	return string.char(#data)..data
end

Server = {

startServer = function()
	love.window.setTitle("Goon Squad 2 Server")
	state = 5
	receivers = {}
end;

tickServer = function(dt)
	if state == 5 then
		if startDelta-lastHolePunch > holePunchTickRate then
			lastHolePunch = startDelta
			local data,ip,port
			repeat
				data,ip,port = udp:receivefrom()
				if data then
					if data:sub(1,2) == string.char(255)..string.char(0) then
						startGame(1)
						return
					end
				elseif ip ~= "timeout" then
					if ip == "closed" then
						print("Hole punch server not running - please contatct Devin")
					else
						print("Error:",ip,port)
					end
				end
			until not data
			udp:sendto(string.char(255)..string.char(7)..string.char(0),Network.holePunchIP,holePunchPort)
		end
	else
		serverUpdateTime = serverUpdateTime+dt
		serverSendTime = serverSendTime+dt
		if serverUpdateTime > serverUpdateRate then
			serverUpdateTime = serverUpdateTime-serverUpdateRate
			local send = serverSendTime > serverSendRate
			if send then
				serverSendTime = serverSendTime-serverSendRate
			end
			local data,ip,port
			repeat
				data,ip,port = udp:receivefrom()
				if data then
					if love.keyboard.isDown("f2") then
						print(getBytes(data))
					end
					local r
					for _,v in pairs(receivers) do
						if v.ip == ip and v.port == port then
							r = v
							r.lastReceived = startDelta
							break
						end
					end
					local h = data:byte(1)
					if h == 0 then -- add receiver
						if not r then
							table.insert(receivers,{ip=ip,port=port,lastReceived=startDelta})
							print("Connection from ",ip..":"..port)
						end
					elseif h == 1 then
						local p = addPlayer(data:byte(2),1)
						if p then
							p.ip,p.port,p.lastReceived = ip,port,startDelta
						end
					elseif h == 2 then
						local i = 2
						while i <= #data do
							local playerN = data:byte(i)
							local length = data:byte(i+1)
							if players[playerN] then
								unpackPlayer(players[playerN],data:sub(i+2,i+length+1))
							end
							i = i+length+2
						end
					elseif h == 255 then
						local h2 = data:byte(2)
						if h2 == 1 then
							local ip,port = getIPFromBytes(data:sub(3,8))
							udp:sendto(string.char(255)..string.char(2)..data:sub(9,14),ip,port)
						end
					end
				elseif ip ~= "timeout" then
					print("Error:",ip,port)
				end
			until not data
			for i = #receivers, 1, -1 do
				local r = receivers[i]
				if startDelta-r.lastReceived > killClientTimeout then -- only checks if the client owning the player disconnects
					print("Disconnected client",r.ip..":"..r.port)
					table.remove(receivers,i)
				end
			end
			for i2,v in pairs(players) do
				local j = v.joystick
				if j.isNetwork and startDelta-v.lastReceived > killClientTimeout then
					print("Disconnecting player "..i2.." from",v.ip..":"..v.port)
					removePlayer(i2)
				end
			end
			if send then
				local playerDatas = {}
				for i,v in pairs(players) do
					playerDatas[i] = {}
					playerDatas[i].notOwned = packPlayer(v)
					playerDatas[i].serverPack = packPlayerFromServer(v)
				end
				local worldSegment = string.char(0)..packWorld()
				for i2 = 1, #receivers do
					local r = receivers[i2]
					local sendData = worldSegment
					for i,v in pairs(players) do
						local playerData = string.char(i)
						local owned = v.ip == r.ip and v.port == r.port
						if not owned then
							playerData = playerData..playerDatas[i].notOwned
						end
						sendData = sendData..string.char(playerData:len()-1)..playerData..playerDatas[i].serverPack
					end
					udp:sendto(sendData,r.ip,r.port)
				end
			end
		end
	end
end;

}
return Server