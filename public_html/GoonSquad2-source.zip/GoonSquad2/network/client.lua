local Network = require"network/network"
local udp,holePunchPort = Network.udp,Network.holePunchPort

local unpackPlayer,getIPFromBytes,getBytes,packPlayer = Network.unpackPlayer,Network.getIPFromBytes,Network.getBytes,Network.packPlayer

local clientUpdateRate = 0
local clientSendRate = 1/60
local clientUpdateTime = 0
local clientSendTime = 0

local lastReceived = 0

local lastHolePunch = 0
local holePunchTickRate = 0.1

local requestQueue = {}

local disconnectTimeout = 3

local serverIP,serverPort
local Client

local function unpackPlayerFromServer(player,data)
	local t = data:byte(1)
	local p21 = 1
	local p2 = 2
	local flags = {}
	for i = 1, 8 do
		if t == 0 then
			break
		end
		if t%p2 == p21 then
			t = t-p21
			flags[i] = true
		end
		p21,p2 = p2,p2*2
	end
	local i = 2
	if flags[1] then
		player.sword = gameTime-data:byte(i)/255
		i = i+1
	end
	if flags[2] then
		player.jetpack = data:byte(i)/255*jetpackFuel
		i = i+1
	else
		player.jetpack = nil -- fix this
	end
	if flags[3] then
		player.speedDrop = gameTime-data:byte(i)/255*speedDropDuration
		i = i+1
	else
		player.speedDrop = nil
	end
	return
end

local function unpackUpdate(data)
	if state == 4 then
		startGame(2) -- 2 means client mode
		Client.removeRequestQueue(string.char(0),true)
	end
	local i = 1
	local length = data:byte(i)
	for j = 1, length do
		worldState.drops[j] = data:byte(i+j)
	end
	i = i+length+1
	local localPlayers = {}
	for i,v in pairs(players) do
		localPlayers[i] = true
	end
	while i <= #data do
		local length1 = data:byte(i)
		i = i+1
		local playerN = data:byte(i)
		i = i+1
		local owned = length1 == 0
		localPlayers[playerN] = nil
		if not owned then
			if not players[playerN] then
				addPlayer(playerN,1)
			end
			unpackPlayer(players[playerN],data:sub(i,i+length1-1))
		else -- this player belongs to this client
			if not players[playerN] then -- if this client doesn't know about this player, and its owned, then it must have requested it
				addPlayer(playerN,0)
			end
		end
		i = i+length1
		local length2 = data:byte(i)
		i = i+1
		if players[playerN] then
			unpackPlayerFromServer(players[playerN],data:sub(i,i+length2-1)) -- if client reconnects too fast, error
		end
		i = i+length2
	end
	for i,v in pairs(localPlayers) do
		removePlayer(i)
	end
end

Client = {
requestQueue = requestQueue;
joinServer = function()
	for i = #requestQueue, 1, -1 do
		table.remove(requestQueue,i)
	end
	love.window.setTitle("Goon Squad 2 Client")
	state = 6
end;
queueRequest = function(message,data)
	table.insert(requestQueue,{message=message,data=data})
end;
removeRequestQueue = function(message,removeAll)
	for i = 1, #requestQueue do
		if requestQueue[i].message == message then
			table.remove(requestQueue,i)
			if not removeAll then
				break
			end
		end
	end
end;
tickClient = function(dt)
	if state == 6 then
		if startDelta-lastHolePunch > holePunchTickRate then
			lastHolePunch = startDelta
			local data,ip,port
			repeat
				data,ip,port = udp:receivefrom()
				if data then
					local h = data:byte(1)
					if h == 255 then
						local h2 = data:byte(2)
						if h2 == 1 then -- recieved server IP address, lets send a ping to the server
							local ip,port = getIPFromBytes(data:sub(3,8))
							udp:sendto(string.char(255)..string.char(2)..data:sub(9,14),ip,port)
						elseif h2 == 2 then
							local serverIP2,serverPort2 = getIPFromBytes(data:sub(3,8))
							serverIP,serverPort = ip,port
							print(serverIP,serverPort,serverIP2,serverPort2)
							print("Connecting to "..serverIP..":"..serverPort)
							state = 4
							Client.queueRequest(string.char(0),{"connect"})
						end
					end
				elseif ip ~= "timeout" then
					if ip == "closed" then
						print("Hole punch server not running - please contatct Devin")
					else
						print("Error:",ip,port)
					end
				end
			until not data
			udp:sendto(string.char(255)..string.char(7)..string.char(1),Network.holePunchIP,holePunchPort)
		end
	else
		clientUpdateTime = clientUpdateTime+dt
		clientSendTime = clientSendTime+dt
		if clientUpdateTime > clientUpdateRate then
			clientUpdateTime = clientUpdateTime-clientUpdateRate
			local send = clientSendTime > clientSendRate
			if send then
				clientSendTime = clientSendTime-clientSendRate
			end
			local data,msg
			repeat
				data,msg = udp:receive()
				if data then
					if love.keyboard.isDown("f2") then
						print(getBytes(data))
					end
					lastReceived = startDelta
					local h = data:byte(1)
					if h == 0 then
						if #data > 1 then
							unpackUpdate(data:sub(2))
						end
					end
				else
					if startDelta-lastReceived > disconnectTimeout and state == 3 then
						mainMenu()
					end
					if msg == "closed" then
					elseif msg ~= "timeout" then
						print("Error:",msg)
					end
				end
			until not data
			if send then
				if #requestQueue > 0 then
					print(#requestQueue.." pending requests")
				end
				local r = {}
				for i = #requestQueue, 1, -1 do
					local send = true
					if requestQueue[i].message:byte(1) == 1 then -- if it is an add player request, cancel it if its adding an existing player
						local pN = requestQueue[i].message:byte(2)
						if pN > maxPlayers or players[pN] then
							send = false
						end
					end
					if send then
						udp:sendto(requestQueue[i].message,serverIP,serverPort)
					else
						table.remove(requestQueue,i)
					end
				end
				local packetData = string.char(2)
				for i,v in pairs(players) do
					if not v.joystick.isNetwork then
						local playerData = packPlayer(v)
						packetData = packetData..string.char(i)..string.char(#playerData)..playerData
					end
				end
				udp:sendto(packetData,serverIP,serverPort)
			end
		end
	end
end;

}
return Client